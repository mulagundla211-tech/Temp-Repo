### TELECALLING • ADMISSION LEAD MANAGEMENT Application for Shastra Jr College

**System Overview**
This enterprise-grade Admission CRM is designed specifically to optimize high-volume telecalling, field visit tracking, and multi-tiered lead management. The system enforces strict data governance across a 50+ user marketing organization while providing a frictionless, mobile-responsive data entry experience for on-ground staff.

---

### 1. System Architecture & Infrastructure

To support high concurrency and rapid iteration, the application architecture separates the frontend presentation layer from the core API and database.

* **Database:** PostgreSQL. Ensures ACID compliance for concurrent lead updates, with JSONB support for dynamic conversion checklists.


* **Frontend UI:** HTML5 and Bootstrap 5. Guarantees a lightweight, immediately responsive interface optimized for field agents accessing the platform via mobile networks.


* **API Layer:** RESTful architecture handling authentication, role validation, and data routing between the client and database.
* **Deployment Strategy:** Containerized application components utilizing Docker, deployed to a VPS environment. Using a platform like Coolify for CI/CD pipeline management will streamline updates and isolate the database from the web application containers.

---

### 2. Enhanced Role-Based Access & Workflows

The 5-tier access model is structured to prevent data leakage while maximizing telecaller output and field accountability.

* **Staff (Telecallers / Admission Desk):** Restricted to their assigned lead queues. Workflow focuses on velocity: updating the Lead Status (HOT, WARM, CALLBACK, PENDING, LOST), logging call attempts (`callno`), updating the Conversion Checklist, and escalating required home visits to the On-Field team.


* **On-Field (Doorstep Representatives):** Mobile-first access. They receive a filtered queue of leads flagged for home visits. They log the Entry Date, review the Student/Father Name and Address, and submit the Visiting Report detailing parent objections and interest levels.


* **Management:** Strategic oversight. Accesses high-level dashboards to monitor aggregated daily sales performance, conversion bottlenecks, and pipeline velocity across the 50-person team, without write access to operational data.
* **Admin:** Operational oversight. Manages day-to-day user accounts for Staff and On-Field teams. Capable of reassigning leads, managing data imports/exports, and reviewing individual employee performance metrics (e.g., calls made per day, field visits completed).
* **SuperAdmin:** Technical oversight. Full CRUD access to all system data, global configurations, and the creation of Admin and Management accounts.

---

### 3. Core Telecalling & Lead Management Features

To elevate the application from a basic data-entry form to a true Telecalling CRM, the following functional workflows are required:

* **Smart Follow-Up Engine:** Instead of manually searching for leads, Staff are presented with an automated daily queue based strictly on the `next_followup_date` and `next_followup_time` parameters.


* **Lead Journey Timeline:** A visual, sequential timeline for every student profile mapping the entire lifecycle: initial walk-in/call -> telecaller follow-ups -> on-field visit completion -> final admission confirmation.
* **Click-to-Call Integration:** Telephone numbers (`student_mobile`, `parent_mobile`) function as `tel:` URI links, allowing telecallers to initiate calls directly via softphones or mobile devices.


* **Call Disposition Logging:** Moving beyond simply updating the lead, telecallers must log the outcome of every specific call attempt (e.g., "No Answer," "Requested Callback," "Not Interested") to build accurate metrics for the `callno` tally.


* **Geo-Tagged Field Visits (Optional Enhancement):** For on-field accountability, the mobile web interface can capture the agent's GPS coordinates upon submitting the Visiting Report to verify proximity to the student's address.



---

### 4. Optimized PostgreSQL Schema

The database is normalized to track historical interactions (call logs and field visits) against the primary lead profile.

#### Table: `users`

* `user_id` (UUID, Primary Key)
* `username` / `email` (VARCHAR, Unique)
* `password_hash` (VARCHAR)
* `role` (VARCHAR: SuperAdmin, Admin, Management, Staff, OnField)
* `is_active` (BOOLEAN)

#### Table: `leads` (Core Student Profile)

* **Identity:** `lead_id` (VARCHAR PK), `student_name` (VARCHAR), `gender` (CHAR), `parent_name` (VARCHAR), `relation` (VARCHAR).


* **Contact:** `student_mobile` (VARCHAR), `parent_mobile` (VARCHAR), `location` (VARCHAR), `whatsapp_opt_in` (BOOLEAN).


* **Academics:** `current_school` (VARCHAR), `class` (VARCHAR), `board` (VARCHAR), `academic_year` (VARCHAR), `target_course` (VARCHAR), `goal` (VARCHAR), `academic_level` (VARCHAR), `expected_score` (VARCHAR).


* **Sales Pipeline:** `source` (VARCHAR), `lead_type` (VARCHAR), `preferred_campus` (VARCHAR), `program_discussed` (VARCHAR), `quoted_fee` (DECIMAL), `expected_budget` (DECIMAL), `scholarship_status` (VARCHAR), `parent_objections` (TEXT).


* **Status Indicators:** `lead_status` (VARCHAR), `next_followup_date` (DATE), `next_followup_time` (TIME), `counselling_appointment` (BOOLEAN), `campus_visit` (VARCHAR), `expected_admission_date` (DATE).


* **Conversion Metrics:** `is_interested` (BOOLEAN), `is_parent_convinced` (BOOLEAN), `is_fee_discussed` (BOOLEAN), `is_hostel_explained` (BOOLEAN), `is_admission_confirmed` (BOOLEAN).



#### Table: `call_logs` (1-to-Many Relationship with Leads)

Tracks the telecalling velocity referenced by the frontend `callno` metric.

* `log_id` (UUID, Primary Key)
* `lead_id` (VARCHAR, Foreign Key to `leads`)
* `telecaller_id` (UUID, Foreign Key to `users`)
* `call_timestamp` (TIMESTAMP)
* `call_outcome` (VARCHAR: Answered, Unanswered, Invalid Number)
* `followup_notes` (TEXT)



#### Table: `field_visits` (1-to-Many Relationship with Leads)

* `visit_id` (UUID, Primary Key)
* `lead_id` (VARCHAR, Foreign Key referencing `leads.lead_id`)


* `field_employee_id` (UUID, Foreign Key to `users`)
* `entry_date` (DATE)


* `address_visited` (VARCHAR)


* `area` (VARCHAR)


* `contact_verified` (VARCHAR)


* `visit_report` (TEXT)



---

### 5. Frontend Modules & Interface Specifications

* **Unified Dashboard:** Dynamically renders based on the user role. Staff see personal metrics (Total Calls, Follow-ups). Management/Admins see team aggregates (Conversion Rate, Quoted Fee Value, Hot Leads). Includes the visual Lead Pipeline and Recent Leads data table.


* **Telecaller Data Entry:** A streamlined, tabbed or multi-section form capturing Caller Control, Student Profile, Academic Requirements, Fee Discussion, and Status/Follow-up.


* **Follow-up Tracker:** The primary workspace for Staff. A filtered, chronological list prioritizing leads based on scheduled dates and times.


* **On-Field Module:** A distinct, mobile-optimized view for doorstep representatives to log Entry Date, Employee Name, and the Visit Report without navigating the complex telecalling forms.
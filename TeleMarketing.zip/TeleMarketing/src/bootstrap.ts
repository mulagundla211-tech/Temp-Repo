import 'dotenv/config';
import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { password } from './domain.js';
import { createPool, transaction } from './db.js';

const env = z.object({
  DATABASE_URL: z.string().min(1),
  BOOTSTRAP_EMAIL: z.string().email().transform(v => v.toLowerCase()),
  BOOTSTRAP_USERNAME: z.string().trim().min(2).max(100),
  BOOTSTRAP_PASSWORD: password
}).parse(process.env);
const pool = createPool(env.DATABASE_URL);
try {
  const hash = await bcrypt.hash(env.BOOTSTRAP_PASSWORD, 12);
  await transaction(pool, async client => {
    await client.query('SELECT pg_advisory_xact_lock(418294)');
    const existing = await client.query("SELECT 1 FROM users WHERE role = 'SuperAdmin'");
    if (existing.rowCount) throw new Error('A SuperAdmin already exists; use account administration instead.');
    await client.query('INSERT INTO users (user_id,username,email,password_hash,role) VALUES ($1,$2,$3,$4,$5)',
      [randomUUID(), env.BOOTSTRAP_USERNAME, env.BOOTSTRAP_EMAIL, hash, 'SuperAdmin']);
  });
  console.log('Initial SuperAdmin created.');
} finally { await pool.end(); }

import pg from 'pg';
import type { PoolClient } from 'pg';

// Preserve date-only and local follow-up time values, independent of the host timezone.
pg.types.setTypeParser(1082, value => value);
export function createPool(connectionString: string) {
  return new pg.Pool({ connectionString, max: 20, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000 });
}
export async function transaction<T>(pool: pg.Pool, work: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

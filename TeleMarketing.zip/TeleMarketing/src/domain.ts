import { z } from 'zod';

export const roles = ['SuperAdmin', 'Admin', 'Management', 'Staff', 'OnField'] as const;
export type Role = typeof roles[number];
export interface Actor { user_id: string; username: string; email: string; role: Role }
export const operators: Role[] = ['SuperAdmin', 'Admin'];
export const writers: Role[] = [...operators, 'Staff'];
export const statuses = ['HOT', 'WARM', 'CALLBACK', 'PENDING', 'LOST'] as const;
export const outcomes = ['Answered', 'Unanswered', 'Invalid Number', 'Requested Callback', 'Not Interested'] as const;
const text = z.string().trim().max(250).default('');
const notes = z.string().trim().max(5000).default('');
const phone = z.string().trim().regex(/^(?:\+?[0-9 ()-]{7,20})?$/, 'Enter a valid phone number').default('');
export const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v => {
  const d = new Date(`${v}T00:00:00Z`);
  return !v.startsWith('0000-') && !Number.isNaN(d.valueOf()) && d.toISOString().slice(0, 10) === v;
}, 'Invalid calendar date');
const money = z.number().finite().min(0).max(999999999).nullable().default(null);
const flag = z.boolean().default(false);
export const leadSchema = z.object({
  student_name: z.string().trim().min(2).max(150),
  gender: z.enum(['', 'M', 'F', 'O']).default(''),
  parent_name: text, relation: text,
  student_mobile: phone, parent_mobile: phone, location: text,
  address: notes, whatsapp_opt_in: flag,
  current_school: text, class: text, board: text, academic_year: text,
  target_course: text, goal: text, academic_level: text, expected_score: text,
  source: text, lead_type: text, preferred_campus: text, program_discussed: text,
  quoted_fee: money, expected_budget: money, scholarship_status: text, parent_objections: notes,
  lead_status: z.enum(statuses).default('PENDING'),
  next_followup_date: date.nullable().default(null),
  next_followup_time: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/).nullable().default(null),
  counselling_appointment: flag, campus_visit: text,
  expected_admission_date: date.nullable().default(null),
  is_interested: flag, is_parent_convinced: flag, is_fee_discussed: flag,
  is_hostel_explained: flag, is_admission_confirmed: flag
}).strict();
export const validateFollowup = (value: { next_followup_date: string | null; next_followup_time: string | null }) =>
  Boolean(value.next_followup_date) === Boolean(value.next_followup_time);
export const leadInput = leadSchema.refine(validateFollowup, 'Follow-up date and time must be provided together');
export const callInput = z.object({
  call_outcome: z.enum(outcomes),
  followup_notes: z.string().trim().min(1).max(5000),
  lead_status: z.enum(statuses),
  next_followup_date: date.nullable(),
  next_followup_time: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/).nullable(),
  version: z.number().int().positive()
}).strict().refine(validateFollowup, 'Follow-up date and time must be provided together')
  .refine(v => v.call_outcome !== 'Requested Callback' || Boolean(v.next_followup_date),
    'Requested callbacks require a follow-up date and time');
export const uuid = z.string().uuid();
export const password = z.string().min(12).max(72).refine(v => Buffer.byteLength(v, 'utf8') <= 72, 'Password must be at most 72 UTF-8 bytes');
export function canManageRole(actor: Role, target: Role): boolean {
  return actor === 'SuperAdmin' || (actor === 'Admin' && ['Staff', 'OnField'].includes(target));
}
export function csvCell(value: unknown): string {
  let s = value === null || value === undefined ? '' : String(value);
  if (/^[\s]*[=+\-@]/.test(s)) s = `'${s}`;
  return `"${s.replaceAll('"', '""')}"`;
}

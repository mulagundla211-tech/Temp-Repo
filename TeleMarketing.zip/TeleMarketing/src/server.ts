import 'dotenv/config';
import { createApp } from './app.js';
import { createPool } from './db.js';
import { z } from 'zod';

const env = z.object({
  DATABASE_URL: z.string().min(1),
  SESSION_SECRET: z.string().min(32),
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  COOKIE_SECURE: z.enum(['true', 'false']).optional(),
  TRUST_PROXY: z.coerce.number().int().min(0).max(5).default(0)
}).parse(process.env);
const pool = createPool(env.DATABASE_URL);
pool.on('error', error => console.error('Idle PostgreSQL connection failed', error));
const migration = await pool.query('SELECT version FROM schema_migrations WHERE version=1');
if (!migration.rowCount) throw new Error('Database migration 1 is missing. Run npm run db:migrate first.');
const app = createApp(pool, {
  secret: env.SESSION_SECRET, secure: env.COOKIE_SECURE ? env.COOKIE_SECURE === 'true' : env.NODE_ENV === 'production',
  production: env.NODE_ENV === 'production', trustProxy: env.TRUST_PROXY
});
const server = app.listen(env.PORT, () => console.log(`Shastra CRM listening on http://localhost:${env.PORT}`));
const cleanup = setInterval(() => {
  pool.query('DELETE FROM session WHERE expire < now()').catch(error => console.error('Session cleanup failed', error));
}, 15 * 60 * 1000).unref();
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
  clearInterval(cleanup);
  server.close(() => { pool.end().catch(error => { console.error('Database shutdown failed', error); process.exitCode = 1; }); });
});

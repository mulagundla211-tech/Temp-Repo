import express, { type Request, type Response, type NextFunction, type RequestHandler } from 'express';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import type pg from 'pg';
import { z, ZodError } from 'zod';
import { parse } from 'csv-parse/sync';
import { transaction } from './db.js';
import { type Actor, type Role, roles, outcomes, operators, writers, leadInput, leadSchema, callInput, canManageRole, csvCell, date, password, uuid } from './domain.js';

declare module 'express-session' {
  interface SessionData { userId: string; csrf: string; authenticatedAt: number }
}
declare global {
  namespace Express { interface Request { actor: Actor } }
}
class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
const fail = (status: number, message: string): never => { throw new HttpError(status, message); };
const asyncRoute = (fn: (req: Request, res: Response) => Promise<unknown>): RequestHandler =>
  (req, res, next) => { Promise.resolve(fn(req, res)).catch(next); };
const allow = (...allowed: Role[]): RequestHandler => (req, _res, next) =>
  allowed.includes(req.actor.role) ? next() : next(new HttpError(403, 'This action is not allowed for your role.'));
const leadId = (req: Request) => z.string().regex(/^SH-[0-9a-f-]{36}$/).parse(req.params.id);
const userColumns = 'user_id, username, email, role, is_active, created_at';
const fields = Object.keys(leadSchema.shape);
type Db = pg.Pool | pg.PoolClient;
async function audit(db: Db, actor: Actor, action: string, target: string) {
  await db.query('INSERT INTO audit_logs (audit_id,actor_id,action,target) VALUES ($1,$2,$3,$4)',
    [randomUUID(), actor.user_id, action, target]);
}
async function event(db: Db, actor: Actor, id: string, kind: string, detail: object = {}) {
  await db.query('INSERT INTO lead_events (event_id,lead_id,actor_id,event_type,detail) VALUES ($1,$2,$3,$4,$5)',
    [randomUUID(), id, actor.user_id, kind, JSON.stringify(detail)]);
}
async function assignee(db: Db, id: string | null, role: Role) {
  if (!id) return;
  const result = await db.query('SELECT 1 FROM users WHERE user_id=$1 AND role=$2 AND is_active FOR SHARE', [id, role]);
  if (!result.rowCount) fail(400, `Select an active ${role} account.`);
}
async function accessibleLead(db: Db, actor: Actor, id: string, lock = false) {
  const args = [id];
  let where = 'l.lead_id=$1';
  if (actor.role === 'Management') fail(403, 'Management has aggregate reporting access only.');
  if (actor.role === 'Staff') { args.push(actor.user_id); where += ' AND l.assigned_to=$2'; }
  if (actor.role === 'OnField') {
    args.push(actor.user_id);
    where += ' AND EXISTS (SELECT 1 FROM field_visits v WHERE v.lead_id=l.lead_id AND v.field_employee_id=$2)';
  }
  const result = await db.query(`SELECT l.* FROM leads l WHERE ${where}${lock ? ' FOR UPDATE OF l' : ''}`, args);
  if (!result.rowCount) fail(404, 'Lead not found or not assigned to you.');
  return result.rows[0];
}
function checkVersion(lead: { version: number }, version: number) {
  if (lead.version !== version) fail(409, 'This lead changed since you opened it. Reload the lead before saving.');
}
async function insertLead(db: Db, actor: Actor, input: z.infer<typeof leadInput>, assigned: string | null) {
  const id = `SH-${randomUUID()}`;
  const values = fields.map(key => input[key as keyof typeof input]);
  await db.query(`INSERT INTO leads (lead_id,${fields.map(f => `"${f}"`).join(',')},assigned_to,created_by)
    VALUES (${[id, ...values, assigned, actor.user_id].map((_, i) => `$${i + 1}`).join(',')})`,
  [id, ...values, assigned, actor.user_id]);
  await event(db, actor, id, 'Lead created', { source: input.source });
  if (input.is_admission_confirmed) await event(db, actor, id, 'Admission confirmed');
  return id;
}
export interface AppOptions { secret: string; secure: boolean; trustProxy: number; production?: boolean }
export function createApp(pool: pg.Pool, options: AppOptions) {
  if (options.secret.length < 32) throw new Error('SESSION_SECRET must contain at least 32 characters');
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', options.trustProxy);
  app.use(helmet({ contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
    imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], upgradeInsecureRequests: options.secure ? [] : null
  } } }));
  app.use(express.json({ limit: '1mb' }));
  const Store = connectPgSimple(session);
  app.use(session({
    store: new Store({ pool, createTableIfMissing: false, pruneSessionInterval: false }),
    name: 'shastra.sid', secret: options.secret, resave: false, saveUninitialized: false,
    cookie: { httpOnly: true, secure: options.secure, sameSite: 'lax', maxAge: 8 * 60 * 60 * 1000 }
  }));
  app.get('/health', asyncRoute(async (_req, res) => {
    const migration = await pool.query('SELECT version FROM schema_migrations WHERE version=1');
    if (!migration.rowCount) fail(503, 'Database migrations are not ready.');
    res.json({ status: 'ok' });
  }));
  app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store');
    if (!req.session.csrf) req.session.csrf = randomBytes(32).toString('hex');
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      const token = req.get('X-CSRF-Token') || '';
      const expected = req.session.csrf;
      if (Buffer.byteLength(token) !== Buffer.byteLength(expected) || !timingSafeEqual(Buffer.from(token), Buffer.from(expected)))
        return next(new HttpError(403, 'Session verification failed. Reload the page and try again.'));
    }
    next();
  });
  const currentActor = async (req: Request): Promise<Actor | null> => {
    if (!req.session.userId) return null;
    if (!req.session.authenticatedAt || Date.now() - req.session.authenticatedAt > 8 * 60 * 60 * 1000) return null;
    const result = await pool.query(`SELECT ${userColumns} FROM users WHERE user_id=$1 AND is_active`, [req.session.userId]);
    return result.rows[0] || null;
  };
  app.get('/api/auth/me', asyncRoute(async (req, res) => {
    res.json({ user: await currentActor(req), csrf: req.session.csrf });
  }));
  app.post('/api/auth/login', rateLimit({
    windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false,
    message: { error: 'Too many login attempts. Try again in 15 minutes.' }
  }), asyncRoute(async (req, res) => {
    const input = z.object({ email: z.string().email().max(254), password: z.string().min(1).max(200) }).strict().parse(req.body);
    const result = await pool.query('SELECT * FROM users WHERE lower(email)=lower($1)', [input.email]);
    const user = result.rows[0];
    // Perform equivalent password work even when the account is unknown.
    const valid = await bcrypt.compare(input.password, user?.password_hash || '$2b$12$R9h/cIPz0gi.URNNX3kh2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW');
    if (!user?.is_active || !valid) fail(401, 'Invalid email or password.');
    await new Promise<void>((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.userId = user.user_id;
    req.session.authenticatedAt = Date.now();
    req.session.csrf = randomBytes(32).toString('hex');
    await audit(pool, user, 'Signed in', user.user_id);
    res.json({ user: { user_id: user.user_id, username: user.username, email: user.email, role: user.role }, csrf: req.session.csrf });
  }));
  app.use('/api', (req, res, next) => {
    currentActor(req).then(actor => {
      if (!actor) { res.status(401).json({ error: 'Please sign in to continue.' }); return; }
      req.actor = actor;
      next();
    }).catch(next);
  });
  app.post('/api/auth/logout', asyncRoute(async (req, res) => {
    await new Promise<void>((resolve, reject) => req.session.destroy(err => err ? reject(err) : resolve()));
    res.clearCookie('shastra.sid', { httpOnly: true, secure: options.secure, sameSite: 'lax' }).json({ ok: true });
  }));
  app.post('/api/auth/password', asyncRoute(async (req, res) => {
    const input = z.object({ current_password: z.string().min(1).max(200), new_password: password }).strict().parse(req.body);
    await transaction(pool, async client => {
      const result = await client.query('SELECT password_hash FROM users WHERE user_id=$1 FOR UPDATE', [req.actor.user_id]);
      if (!await bcrypt.compare(input.current_password, result.rows[0].password_hash)) fail(400, 'Current password is incorrect.');
      await client.query('UPDATE users SET password_hash=$1 WHERE user_id=$2', [await bcrypt.hash(input.new_password, 12), req.actor.user_id]);
      await client.query("DELETE FROM session WHERE sess->>'userId'=$1 AND sid<>$2", [req.actor.user_id, req.sessionID]);
      await audit(client, req.actor, 'Changed password', req.actor.user_id);
    });
    res.json({ ok: true });
  }));
  app.get('/api/settings', asyncRoute(async (_req, res) => {
    res.json((await pool.query('SELECT college_name,timezone FROM app_settings WHERE id=1')).rows[0]);
  }));
  app.put('/api/settings', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const input = z.object({
      college_name: z.string().trim().min(2).max(150),
      timezone: z.string().max(100).refine(v => { try { new Intl.DateTimeFormat('en', { timeZone: v }); return true; } catch { return false; } }, 'Invalid IANA timezone')
    }).strict().parse(req.body);
    await transaction(pool, async client => {
      const validZone = await client.query('SELECT 1 FROM pg_timezone_names WHERE name=$1', [input.timezone]);
      if (!validZone.rowCount) fail(400, 'Timezone is not supported by the database.');
      await client.query('UPDATE app_settings SET college_name=$1,timezone=$2 WHERE id=1', [input.college_name, input.timezone]);
      await audit(client, req.actor, 'Updated global settings', 'app_settings');
    });
    res.json(input);
  }));
  app.get('/api/assignees', allow(...writers), asyncRoute(async (req, res) => {
    res.json((await pool.query(`SELECT user_id,username,role FROM users WHERE is_active
      AND role = ANY($1::text[]) ORDER BY username`, [operators.includes(req.actor.role) ? ['Staff', 'OnField'] : ['OnField']])).rows);
  }));
  app.get('/api/users', allow(...operators), asyncRoute(async (req, res) => {
    res.json((await pool.query(`SELECT ${userColumns} FROM users ${req.actor.role === 'Admin' ? "WHERE role IN ('Staff','OnField')" : ''} ORDER BY username`)).rows);
  }));
  const userInput = z.object({
    username: z.string().trim().min(2).max(100), email: z.string().email().max(254).transform(v => v.toLowerCase()),
    role: z.enum(roles), is_active: z.boolean(), password: password.optional()
  }).strict();
  app.post('/api/users', allow(...operators), asyncRoute(async (req, res) => {
    const input = userInput.extend({ password }).parse(req.body);
    if (!canManageRole(req.actor.role, input.role)) fail(403, 'You can only manage Staff and OnField accounts.');
    const id = randomUUID();
    await transaction(pool, async client => {
      await client.query('INSERT INTO users (user_id,username,email,role,is_active,password_hash) VALUES ($1,$2,$3,$4,$5,$6)',
        [id, input.username, input.email, input.role, input.is_active, await bcrypt.hash(input.password, 12)]);
      await audit(client, req.actor, 'Created account', id);
    });
    res.status(201).json({ user_id: id });
  }));
  app.put('/api/users/:id', allow(...operators), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = userInput.parse(req.body);
    await transaction(pool, async client => {
      const old = (await client.query('SELECT * FROM users WHERE user_id=$1 FOR UPDATE', [id])).rows[0];
      if (!old) fail(404, 'User not found.');
      if (!canManageRole(req.actor.role, old.role) || !canManageRole(req.actor.role, input.role)) fail(403, 'You cannot manage this account.');
      if (id === req.actor.user_id && (!input.is_active || input.role !== old.role)) fail(400, 'You cannot deactivate or change your own role.');
      if ((!input.is_active || old.role !== input.role) && old.role === 'SuperAdmin') {
        await client.query('SELECT pg_advisory_xact_lock(418295)');
        const remaining = await client.query("SELECT 1 FROM users WHERE role='SuperAdmin' AND is_active AND user_id<>$1", [id]);
        if (!remaining.rowCount) fail(400, 'At least one active SuperAdmin must remain.');
      }
      if (!input.is_active || old.role !== input.role) {
        const assigned = await client.query(`SELECT 1 FROM leads WHERE assigned_to=$1
          UNION ALL SELECT 1 FROM field_visits WHERE field_employee_id=$1 AND status='REQUESTED' LIMIT 1`, [id]);
        if (assigned.rowCount) fail(409, 'Reassign this account’s leads and open field visits before changing its role or deactivating it.');
      }
      await client.query('UPDATE users SET username=$1,email=$2,role=$3,is_active=$4,password_hash=$5 WHERE user_id=$6',
        [input.username, input.email, input.role, input.is_active, input.password ? await bcrypt.hash(input.password, 12) : old.password_hash, id]);
      await client.query("DELETE FROM session WHERE sess->>'userId'=$1", [id]);
      await audit(client, req.actor, 'Updated account', id);
    });
    res.json({ ok: true });
  }));
  app.delete('/api/users/:id', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    if (id === req.actor.user_id) fail(400, 'You cannot delete your own account.');
    await transaction(pool, async client => {
      const deleted = await client.query('DELETE FROM users WHERE user_id=$1 RETURNING user_id', [id]);
      if (!deleted.rowCount) fail(404, 'User not found.');
      await client.query("DELETE FROM session WHERE sess->>'userId'=$1", [id]);
      await audit(client, req.actor, 'Deleted account', id);
    });
    res.json({ ok: true });
  }));
  app.get('/api/audit', allow('SuperAdmin'), asyncRoute(async (_req, res) => {
    res.json((await pool.query(`SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.user_id=a.actor_id
      ORDER BY a.created_at DESC LIMIT 200`)).rows);
  }));
  app.get('/api/leads', allow(...writers), asyncRoute(async (req, res) => {
    const query = z.object({
      search: z.string().max(100).default(''), status: z.enum(['', 'HOT', 'WARM', 'CALLBACK', 'PENDING', 'LOST']).default(''),
      queue: z.enum(['all', 'due', 'upcoming', 'unscheduled']).default('all'),
      sort: z.enum(['followup', 'recent']).default('followup'),
      page: z.coerce.number().int().min(1).max(100000).default(1)
    }).parse(req.query);
    const args: unknown[] = [];
    const conditions: string[] = ['TRUE'];
    const bind = (v: unknown) => { args.push(v); return `$${args.length}`; };
    if (req.actor.role === 'Staff') conditions.push(`l.assigned_to=${bind(req.actor.user_id)}`);
    if (query.status) conditions.push(`l.lead_status=${bind(query.status)}`);
    if (query.search) {
      const parameter = bind(`%${query.search.replace(/[\\%_]/g, '\\$&')}%`);
      conditions.push(`(l.student_name ILIKE ${parameter} OR l.parent_name ILIKE ${parameter} OR l.student_mobile ILIKE ${parameter} OR l.parent_mobile ILIKE ${parameter})`);
    }
    if (query.queue !== 'all') conditions.push("NOT l.is_admission_confirmed AND l.lead_status<>'LOST'");
    if (['due', 'upcoming'].includes(query.queue)) {
      conditions.push(`l.next_followup_date+l.next_followup_time ${query.queue === 'due' ? '<=' : '>'} (now() AT TIME ZONE (SELECT timezone FROM app_settings WHERE id=1))`);
    }
    if (query.queue === 'unscheduled') conditions.push('l.next_followup_date IS NULL');
    const where = conditions.join(' AND ');
    const count = await pool.query(`SELECT count(*)::int AS total FROM leads l WHERE ${where}`, args);
    const offset = bind((query.page - 1) * 25);
    const result = await pool.query(`SELECT l.lead_id,l.student_name,l.parent_name,l.student_mobile,l.parent_mobile,l.location,
      l.target_course,l.lead_status,l.next_followup_date,to_char(l.next_followup_time,'HH24:MI') AS next_followup_time,
      l.is_admission_confirmed,l.created_at,l.version,u.username AS assigned_name,
      (SELECT count(*)::int FROM call_logs c WHERE c.lead_id=l.lead_id) AS callno
      FROM leads l LEFT JOIN users u ON u.user_id=l.assigned_to WHERE ${where}
      ORDER BY ${query.sort === 'recent' ? '' : 'l.next_followup_date ASC NULLS LAST,l.next_followup_time ASC NULLS LAST,'}l.created_at DESC,l.lead_id LIMIT 25 OFFSET ${offset}`, args);
    res.json({ items: result.rows, total: count.rows[0].total, page: query.page, page_size: 25 });
  }));
  app.post('/api/leads', allow(...writers), asyncRoute(async (req, res) => {
    const { assigned_to, ...data } = z.object({ ...leadSchema.shape, assigned_to: uuid.nullable().optional() }).strict().parse(req.body);
    const input = leadInput.parse(data);
    if (req.actor.role === 'Staff' && assigned_to && assigned_to !== req.actor.user_id) fail(403, 'Staff can only create leads in their own queue.');
    const assigned = req.actor.role === 'Staff' ? req.actor.user_id : assigned_to || null;
    const id = await transaction(pool, async client => {
      await assignee(client, assigned, 'Staff');
      return insertLead(client, req.actor, input, assigned);
    });
    res.status(201).json({ lead_id: id });
  }));
  app.get('/api/leads/export', allow(...operators), asyncRoute(async (req, res) => {
    const data = await pool.query(`SELECT lead_id,${fields.map(f => `"${f}"`).join(',')},assigned_to FROM leads ORDER BY created_at LIMIT 10001`);
    if (data.rows.length > 10000) fail(400, 'Export exceeds 10,000 rows. Use an administrator database export for this volume.');
    const headers = ['lead_id', ...fields, 'assigned_to'];
    await audit(pool, req.actor, 'Exported leads', `${data.rows.length} rows`);
    res.type('text/csv').attachment('shastra-leads.csv').send(
      headers.join(',') + '\r\n' + data.rows.map(row => headers.map(key => csvCell(row[key])).join(',')).join('\r\n'));
  }));
  app.post('/api/leads/import', allow(...operators), express.text({ type: 'text/csv', limit: '2mb' }), asyncRoute(async (req, res) => {
    if (typeof req.body !== 'string') fail(400, 'Upload a UTF-8 CSV with Content-Type text/csv.');
    let rows: Record<string, string>[];
    try {
      rows = parse(req.body, { columns: true, skip_empty_lines: true, bom: true, trim: true, max_record_size: 20000 });
    } catch (error) { throw new HttpError(400, `Invalid CSV: ${error instanceof Error ? error.message : 'parse error'}`); }
    if (!rows.length || rows.length > 2000) fail(400, 'Import must contain between 1 and 2,000 leads.');
    const inputs = rows.map((row, index) => {
      const raw: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(row)) {
        if (key !== 'assigned_to' && !fields.includes(key)) fail(400, `Row ${index + 2}: unsupported column "${key}". Import accepts new leads only; omit lead_id.`);
        if (value === '') continue;
        if (['quoted_fee', 'expected_budget'].includes(key)) raw[key] = Number(value);
        else if (key.startsWith('is_') || ['whatsapp_opt_in', 'counselling_appointment'].includes(key)) {
          if (!['true', 'false'].includes(value.toLowerCase())) fail(400, `Row ${index + 2}: ${key} must be true or false.`);
          raw[key] = value.toLowerCase() === 'true';
        } else raw[key] = value;
      }
      const assigned = uuid.nullable().parse(raw.assigned_to || null);
      delete raw.assigned_to;
      const parsed = leadInput.safeParse(raw);
      if (!parsed.success) fail(400, `Row ${index + 2}: ${parsed.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; ')}`);
      return { input: parsed.data!, assigned };
    });
    await transaction(pool, async client => {
      for (const item of inputs) {
        await assignee(client, item.assigned, 'Staff');
        await insertLead(client, req.actor, item.input, item.assigned);
      }
      await audit(client, req.actor, 'Imported leads', `${inputs.length} rows`);
    });
    res.status(201).json({ imported: inputs.length });
  }));
  app.get('/api/leads/:id', allow(...writers, 'OnField'), asyncRoute(async (req, res) => {
    const lead = await accessibleLead(pool, req.actor, leadId(req));
    if (req.actor.role === 'OnField') {
      res.json({ lead_id: lead.lead_id, student_name: lead.student_name, parent_name: lead.parent_name,
        student_mobile: lead.student_mobile, parent_mobile: lead.parent_mobile, address: lead.address, location: lead.location,
        parent_objections: lead.parent_objections, target_course: lead.target_course });
      return;
    }
    lead.next_followup_time = lead.next_followup_time?.slice(0, 5) || null;
    const calls = await pool.query(`SELECT c.*,u.username FROM call_logs c JOIN users u ON u.user_id=c.telecaller_id
      WHERE lead_id=$1 ORDER BY call_timestamp DESC`, [lead.lead_id]);
    const visits = await pool.query(`SELECT v.*,u.username FROM field_visits v JOIN users u ON u.user_id=v.field_employee_id
      WHERE lead_id=$1 ORDER BY requested_at DESC`, [lead.lead_id]);
    const timeline = await pool.query(`SELECT e.*,u.username FROM lead_events e JOIN users u ON u.user_id=e.actor_id
      WHERE lead_id=$1 ORDER BY e.created_at DESC,e.event_id DESC`, [lead.lead_id]);
    res.json({ ...lead, callno: calls.rowCount, calls: calls.rows, visits: visits.rows, timeline: timeline.rows });
  }));
  app.put('/api/leads/:id', allow(...writers), asyncRoute(async (req, res) => {
    const { version, ...data } = leadSchema.extend({ version: z.number().int().positive() }).strict().parse(req.body);
    const input = leadInput.parse(data);
    const id = leadId(req);
    await transaction(pool, async client => {
      const old = await accessibleLead(client, req.actor, id, true);
      checkVersion(old, version);
      const values = fields.map(key => input[key as keyof typeof input]);
      await client.query(`UPDATE leads SET ${fields.map((f, i) => `"${f}"=$${i + 1}`).join(',')},
        version=version+1,updated_at=now() WHERE lead_id=$${fields.length + 1}`, [...values, id]);
      const changed = fields.filter(key => String(old[key] ?? '') !== String(input[key as keyof typeof input] ?? ''));
      await event(client, req.actor, id, 'Profile updated', { fields: changed, status: input.lead_status });
      if (old.is_admission_confirmed !== input.is_admission_confirmed)
        await event(client, req.actor, id, input.is_admission_confirmed ? 'Admission confirmed' : 'Admission confirmation removed');
    });
    res.json({ ok: true });
  }));
  app.put('/api/leads/:id/assignment', allow(...operators), asyncRoute(async (req, res) => {
    const input = z.object({ assigned_to: uuid.nullable(), version: z.number().int().positive() }).strict().parse(req.body);
    const id = leadId(req);
    await transaction(pool, async client => {
      const old = await accessibleLead(client, req.actor, id, true);
      checkVersion(old, input.version);
      await assignee(client, input.assigned_to, 'Staff');
      await client.query('UPDATE leads SET assigned_to=$1,version=version+1,updated_at=now() WHERE lead_id=$2', [input.assigned_to, id]);
      await event(client, req.actor, id, 'Lead reassigned', { assigned_to: input.assigned_to });
    });
    res.json({ ok: true });
  }));
  app.delete('/api/leads/:id', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const id = leadId(req);
    const input = z.object({ version: z.number().int().positive() }).strict().parse(req.body);
    await transaction(pool, async client => {
      checkVersion(await accessibleLead(client, req.actor, id, true), input.version);
      await client.query('DELETE FROM leads WHERE lead_id=$1', [id]);
      await audit(client, req.actor, 'Deleted lead and associated history', id);
    });
    res.json({ ok: true });
  }));
  app.post('/api/leads/:id/calls', allow(...writers), asyncRoute(async (req, res) => {
    const input = callInput.parse(req.body);
    const id = leadId(req);
    await transaction(pool, async client => {
      checkVersion(await accessibleLead(client, req.actor, id, true), input.version);
      await client.query('INSERT INTO call_logs (log_id,lead_id,telecaller_id,call_outcome,followup_notes) VALUES ($1,$2,$3,$4,$5)',
        [randomUUID(), id, req.actor.user_id, input.call_outcome, input.followup_notes]);
      await client.query(`UPDATE leads SET lead_status=$1,next_followup_date=$2,next_followup_time=$3,
        version=version+1,updated_at=now() WHERE lead_id=$4`, [input.lead_status, input.next_followup_date, input.next_followup_time, id]);
      await event(client, req.actor, id, 'Call logged', { outcome: input.call_outcome, notes: input.followup_notes,
        followup: input.next_followup_date ? `${input.next_followup_date} ${input.next_followup_time}` : null });
    });
    res.status(201).json({ ok: true });
  }));
  app.post('/api/leads/:id/visits', allow(...writers), asyncRoute(async (req, res) => {
    const input = z.object({ field_employee_id: uuid, request_notes: z.string().trim().min(1).max(5000) }).strict().parse(req.body);
    const id = leadId(req);
    await transaction(pool, async client => {
      await accessibleLead(client, req.actor, id, true);
      await assignee(client, input.field_employee_id, 'OnField');
      await client.query('INSERT INTO field_visits (visit_id,lead_id,field_employee_id,requested_by,request_notes) VALUES ($1,$2,$3,$4,$5)',
        [randomUUID(), id, input.field_employee_id, req.actor.user_id, input.request_notes]);
      await event(client, req.actor, id, 'Home visit requested', { notes: input.request_notes });
    });
    res.status(201).json({ ok: true });
  }));
  app.put('/api/calls/:id', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = z.object({
      call_outcome: z.enum(outcomes),
      followup_notes: z.string().trim().min(1).max(5000),
      correction_reason: z.string().trim().min(5).max(500)
    }).strict().parse(req.body);
    await transaction(pool, async client => {
      const result = await client.query('UPDATE call_logs SET call_outcome=$1,followup_notes=$2 WHERE log_id=$3 RETURNING lead_id',
        [input.call_outcome, input.followup_notes, id]);
      if (!result.rowCount) fail(404, 'Call record not found.');
      await event(client, req.actor, result.rows[0].lead_id, 'Call record corrected', { outcome: input.call_outcome, notes: input.followup_notes, reason: input.correction_reason });
      await audit(client, req.actor, 'Corrected call record', id);
    });
    res.json({ ok: true });
  }));
  app.delete('/api/calls/:id', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = z.object({ correction_reason: z.string().trim().min(5).max(500) }).strict().parse(req.body);
    await transaction(pool, async client => {
      const result = await client.query('DELETE FROM call_logs WHERE log_id=$1 RETURNING lead_id', [id]);
      if (!result.rowCount) fail(404, 'Call record not found.');
      await event(client, req.actor, result.rows[0].lead_id, 'Call record deleted', { notes: input.correction_reason });
      await audit(client, req.actor, 'Deleted call record', id);
    });
    res.json({ ok: true });
  }));
  app.get('/api/visits', allow(...operators, 'OnField'), asyncRoute(async (req, res) => {
    const query = z.object({ status: z.enum(['REQUESTED', 'COMPLETED']).default('REQUESTED'), page: z.coerce.number().int().min(1).default(1) }).parse(req.query);
    const args: unknown[] = [query.status];
    const scope = req.actor.role === 'OnField' ? ' AND v.field_employee_id=$2' : '';
    if (req.actor.role === 'OnField') args.push(req.actor.user_id);
    const count = await pool.query(`SELECT count(*)::int AS total FROM field_visits v WHERE v.status=$1${scope}`, args);
    args.push((query.page - 1) * 25);
    const data = await pool.query(`SELECT v.*,l.student_name,l.parent_name,l.parent_mobile,l.student_mobile,l.location,l.address,
      l.parent_objections,l.target_course,u.username FROM field_visits v JOIN leads l ON l.lead_id=v.lead_id
      JOIN users u ON u.user_id=v.field_employee_id WHERE v.status=$1${scope}
      ORDER BY v.requested_at,v.visit_id LIMIT 25 OFFSET $${args.length}`, args);
    res.json({ items: data.rows, total: count.rows[0].total, page: query.page, page_size: 25 });
  }));
  app.put('/api/visits/:id/assignment', allow(...operators), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = z.object({ field_employee_id: uuid }).strict().parse(req.body);
    await transaction(pool, async client => {
      await assignee(client, input.field_employee_id, 'OnField');
      const result = await client.query("UPDATE field_visits SET field_employee_id=$1 WHERE visit_id=$2 AND status='REQUESTED' RETURNING lead_id", [input.field_employee_id, id]);
      if (!result.rowCount) fail(409, 'Only open visits can be reassigned.');
      await event(client, req.actor, result.rows[0].lead_id, 'Field visit reassigned', { field_employee_id: input.field_employee_id });
    });
    res.json({ ok: true });
  }));
  const visitReport = z.object({
      entry_date: date, address_visited: z.string().trim().min(3).max(5000), area: z.string().trim().min(1).max(250),
      contact_verified: z.enum(['Verified', 'Not available', 'Incorrect address']),
      visit_report: z.string().trim().min(10).max(5000),
      latitude: z.number().min(-90).max(90).nullable().default(null),
      longitude: z.number().min(-180).max(180).nullable().default(null)
    }).strict();
  app.put('/api/visits/:id/complete', allow(...operators, 'OnField'), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = visitReport.refine(v => (v.latitude === null) === (v.longitude === null), 'Provide both GPS coordinates').parse(req.body);
    await transaction(pool, async client => {
      const visit = (await client.query('SELECT * FROM field_visits WHERE visit_id=$1 FOR UPDATE', [id])).rows[0];
      if (!visit || (req.actor.role === 'OnField' && visit.field_employee_id !== req.actor.user_id)) fail(404, 'Visit not found or not assigned to you.');
      if (visit.status !== 'REQUESTED') fail(409, 'This visit has already been completed.');
      const today = (await client.query("SELECT to_char(now() AT TIME ZONE timezone,'YYYY-MM-DD') AS today FROM app_settings WHERE id=1")).rows[0].today;
      if (input.entry_date > today) fail(400, 'Visit entry date cannot be in the future.');
      await client.query(`UPDATE field_visits SET entry_date=$1,address_visited=$2,area=$3,contact_verified=$4,
        visit_report=$5,latitude=$6,longitude=$7,status='COMPLETED',completed_at=now() WHERE visit_id=$8`,
      [input.entry_date, input.address_visited, input.area, input.contact_verified, input.visit_report, input.latitude, input.longitude, id]);
      await event(client, req.actor, visit.lead_id, 'Field visit completed', { report: input.visit_report, contact: input.contact_verified });
    });
    res.json({ ok: true });
  }));
  app.put('/api/visits/:id', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = visitReport.extend({ correction_reason: z.string().trim().min(5).max(500) })
      .refine(v => (v.latitude === null) === (v.longitude === null), 'Provide both GPS coordinates').parse(req.body);
    await transaction(pool, async client => {
      const today = (await client.query("SELECT to_char(now() AT TIME ZONE timezone,'YYYY-MM-DD') AS today FROM app_settings WHERE id=1")).rows[0].today;
      if (input.entry_date > today) fail(400, 'Visit entry date cannot be in the future.');
      const result = await client.query(`UPDATE field_visits SET entry_date=$1,address_visited=$2,area=$3,contact_verified=$4,
        visit_report=$5,latitude=$6,longitude=$7 WHERE visit_id=$8 AND status='COMPLETED' RETURNING lead_id`,
      [input.entry_date, input.address_visited, input.area, input.contact_verified, input.visit_report, input.latitude, input.longitude, id]);
      if (!result.rowCount) fail(409, 'Only completed visit reports can be corrected.');
      await event(client, req.actor, result.rows[0].lead_id, 'Visit report corrected', { report: input.visit_report, reason: input.correction_reason });
      await audit(client, req.actor, 'Corrected visit report', id);
    });
    res.json({ ok: true });
  }));
  app.delete('/api/visits/:id', allow('SuperAdmin'), asyncRoute(async (req, res) => {
    const id = uuid.parse(req.params.id);
    const input = z.object({ correction_reason: z.string().trim().min(5).max(500) }).strict().parse(req.body);
    await transaction(pool, async client => {
      const result = await client.query('DELETE FROM field_visits WHERE visit_id=$1 RETURNING lead_id', [id]);
      if (!result.rowCount) fail(404, 'Visit not found.');
      await event(client, req.actor, result.rows[0].lead_id, 'Field visit deleted', { notes: input.correction_reason });
      await audit(client, req.actor, 'Deleted field visit', id);
    });
    res.json({ ok: true });
  }));
  app.get('/api/dashboard', asyncRoute(async (req, res) => {
    const settings = (await pool.query("SELECT timezone,to_char(now() AT TIME ZONE timezone,'YYYY-MM-DD') AS today FROM app_settings WHERE id=1")).rows[0];
    const input = z.object({ from: date.default(settings.today), to: date.default(settings.today) }).parse(req.query);
    if (input.from > input.to) fail(400, 'Start date must not be after end date.');
    const scoped = req.actor.role === 'Staff';
    const field = req.actor.role === 'OnField';
    const args: unknown[] = scoped || field ? [req.actor.user_id] : [];
    const scope = scoped ? 'WHERE l.assigned_to=$1' : field
      ? 'WHERE EXISTS (SELECT 1 FROM field_visits v WHERE v.lead_id=l.lead_id AND v.field_employee_id=$1)' : '';
    const snapshot = (await pool.query(`SELECT count(*)::int AS total,
      count(*) FILTER (WHERE is_admission_confirmed)::int AS admissions,
      count(*) FILTER (WHERE lead_status='HOT' AND NOT is_admission_confirmed)::int AS hot,
      count(*) FILTER (WHERE NOT is_admission_confirmed AND lead_status<>'LOST' AND next_followup_date+next_followup_time <= (now() AT TIME ZONE (SELECT timezone FROM app_settings WHERE id=1)))::int AS due,
      COALESCE(sum(quoted_fee),0) AS quoted_value,
      count(*) FILTER (WHERE is_interested)::int AS interested,
      count(*) FILTER (WHERE is_parent_convinced)::int AS parent_convinced,
      count(*) FILTER (WHERE is_fee_discussed)::int AS fee_discussed,
      count(*) FILTER (WHERE is_hostel_explained)::int AS hostel_explained
      FROM leads l ${scope}`, args)).rows[0];
    if (field) delete snapshot.quoted_value;
    const pipeline = (await pool.query(`SELECT lead_status,count(*)::int AS count FROM leads l ${scope} ${scope ? 'AND' : 'WHERE'} NOT is_admission_confirmed GROUP BY lead_status`, args)).rows;
    const periodArgs = [input.from, input.to, settings.timezone, ...(scoped || field ? [req.actor.user_id] : [])];
    const employees = (await pool.query(`SELECT u.user_id,u.username,u.role,
      (SELECT count(*)::int FROM call_logs c WHERE c.telecaller_id=u.user_id AND c.call_timestamp >= ($1::date::timestamp AT TIME ZONE $3)
        AND c.call_timestamp < (($2::date+1)::timestamp AT TIME ZONE $3)) AS calls,
      (SELECT count(*)::int FROM field_visits v WHERE v.field_employee_id=u.user_id AND v.completed_at >= ($1::date::timestamp AT TIME ZONE $3)
        AND v.completed_at < (($2::date+1)::timestamp AT TIME ZONE $3)) AS visits,
      (SELECT count(*)::int FROM leads l WHERE l.assigned_to=u.user_id AND l.is_admission_confirmed) AS admissions
      ,(SELECT count(DISTINCT e.lead_id)::int FROM lead_events e WHERE e.actor_id=u.user_id AND e.event_type='Admission confirmed'
        AND e.created_at >= ($1::date::timestamp AT TIME ZONE $3)
        AND e.created_at < (($2::date+1)::timestamp AT TIME ZONE $3)) AS confirmations
      FROM users u ${scoped || field ? 'WHERE u.user_id=$4' : "WHERE u.role IN ('Staff','OnField','Admin','SuperAdmin')"}
      ORDER BY calls DESC,visits DESC,u.username`, periodArgs)).rows;
    const daily = field ? [] : (await pool.query(`WITH calls AS (SELECT to_char(c.call_timestamp AT TIME ZONE $3,'YYYY-MM-DD') AS day,count(*)::int AS calls
      FROM call_logs c WHERE c.call_timestamp >= ($1::date::timestamp AT TIME ZONE $3) AND c.call_timestamp < (($2::date+1)::timestamp AT TIME ZONE $3)
      ${scoped ? 'AND c.telecaller_id=$4' : ''} GROUP BY day),
      confirmations AS (SELECT to_char(e.created_at AT TIME ZONE $3,'YYYY-MM-DD') AS day,count(DISTINCT e.lead_id)::int AS confirmations
        FROM lead_events e WHERE e.event_type='Admission confirmed' AND e.created_at >= ($1::date::timestamp AT TIME ZONE $3)
        AND e.created_at < (($2::date+1)::timestamp AT TIME ZONE $3) ${scoped ? 'AND e.actor_id=$4' : ''} GROUP BY day)
      SELECT COALESCE(c.day,e.day) AS day,COALESCE(c.calls,0) AS calls,COALESCE(e.confirmations,0) AS confirmations
      FROM calls c FULL JOIN confirmations e ON e.day=c.day ORDER BY day`, periodArgs)).rows;
    const velocity = field ? null : (await pool.query(`SELECT round(avg(extract(epoch FROM (e.confirmed-l.created_at))/86400)::numeric,1) AS average_days
      FROM leads l JOIN (SELECT lead_id,min(created_at) AS confirmed FROM lead_events WHERE event_type='Admission confirmed' GROUP BY lead_id) e ON e.lead_id=l.lead_id
      ${scope} ${scope ? 'AND' : 'WHERE'} l.is_admission_confirmed`, args)).rows[0].average_days;
    res.json({ snapshot, pipeline, employees, daily, average_conversion_days: velocity, from: input.from, to: input.to, timezone: settings.timezone });
  }));
  app.use('/api', (_req, res) => { res.status(404).json({ error: 'API endpoint not found.' }); });
  app.use('/vendor', express.static(fileURLToPath(new URL('../node_modules/bootstrap/dist', import.meta.url)), { maxAge: '7d', index: false }));
  app.use(express.static(fileURLToPath(new URL('../public', import.meta.url)), { maxAge: options.production ? '1h' : 0 }));
  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (error instanceof ZodError) {
      res.status(400).json({ error: error.issues.map(i => `${i.path.join('.') || 'Input'}: ${i.message}`).join('; ') });
      return;
    }
    if (error instanceof HttpError) { res.status(error.status).json({ error: error.message }); return; }
    const code = typeof error === 'object' && error !== null && 'code' in error ? error.code : '';
    if (code === '23505') { res.status(409).json({ error: 'A matching account or an open visit already exists.' }); return; }
    if (code === '23503') { res.status(409).json({ error: 'This record is referenced by history. Deactivate the account instead, or refresh and retry.' }); return; }
    if (typeof error === 'object' && error !== null && 'type' in error) {
      if (error.type === 'entity.too.large') { res.status(413).json({ error: 'Upload is too large.' }); return; }
      if (error.type === 'entity.parse.failed') { res.status(400).json({ error: 'Malformed JSON request.' }); return; }
    }
    const incident = randomUUID();
    console.error(`Request failure ${incident}`, error);
    res.status(500).json({ error: `An unexpected server error occurred. Contact your administrator with reference ${incident}.` });
  });
  return app;
}

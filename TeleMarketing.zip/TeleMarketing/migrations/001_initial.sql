CREATE TABLE users (
  user_id UUID PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('SuperAdmin','Admin','Management','Staff','OnField')),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_unique ON users (lower(email));
CREATE UNIQUE INDEX users_username_unique ON users (lower(username));

CREATE TABLE leads (
  lead_id VARCHAR(50) PRIMARY KEY,
  student_name VARCHAR(150) NOT NULL,
  gender CHAR(1) NOT NULL DEFAULT '' CHECK (gender IN ('','M','F','O')),
  parent_name VARCHAR(250) NOT NULL DEFAULT '',
  relation VARCHAR(250) NOT NULL DEFAULT '',
  student_mobile VARCHAR(30) NOT NULL DEFAULT '',
  parent_mobile VARCHAR(30) NOT NULL DEFAULT '',
  location VARCHAR(250) NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  whatsapp_opt_in BOOLEAN NOT NULL DEFAULT FALSE,
  current_school VARCHAR(250) NOT NULL DEFAULT '',
  class VARCHAR(250) NOT NULL DEFAULT '',
  board VARCHAR(250) NOT NULL DEFAULT '',
  academic_year VARCHAR(250) NOT NULL DEFAULT '',
  target_course VARCHAR(250) NOT NULL DEFAULT '',
  goal VARCHAR(250) NOT NULL DEFAULT '',
  academic_level VARCHAR(250) NOT NULL DEFAULT '',
  expected_score VARCHAR(250) NOT NULL DEFAULT '',
  source VARCHAR(250) NOT NULL DEFAULT '',
  lead_type VARCHAR(250) NOT NULL DEFAULT '',
  preferred_campus VARCHAR(250) NOT NULL DEFAULT '',
  program_discussed VARCHAR(250) NOT NULL DEFAULT '',
  quoted_fee NUMERIC(12,2) CHECK (quoted_fee >= 0),
  expected_budget NUMERIC(12,2) CHECK (expected_budget >= 0),
  scholarship_status VARCHAR(250) NOT NULL DEFAULT '',
  parent_objections TEXT NOT NULL DEFAULT '',
  lead_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (lead_status IN ('HOT','WARM','CALLBACK','PENDING','LOST')),
  next_followup_date DATE,
  next_followup_time TIME,
  counselling_appointment BOOLEAN NOT NULL DEFAULT FALSE,
  campus_visit VARCHAR(250) NOT NULL DEFAULT '',
  expected_admission_date DATE,
  is_interested BOOLEAN NOT NULL DEFAULT FALSE,
  is_parent_convinced BOOLEAN NOT NULL DEFAULT FALSE,
  is_fee_discussed BOOLEAN NOT NULL DEFAULT FALSE,
  is_hostel_explained BOOLEAN NOT NULL DEFAULT FALSE,
  is_admission_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
  assigned_to UUID REFERENCES users(user_id),
  created_by UUID NOT NULL REFERENCES users(user_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  version INTEGER NOT NULL DEFAULT 1,
  CHECK ((next_followup_date IS NULL) = (next_followup_time IS NULL))
);
CREATE INDEX leads_assigned_followup ON leads (assigned_to, next_followup_date, next_followup_time);
CREATE INDEX leads_status ON leads (lead_status);
CREATE TABLE call_logs (
  log_id UUID PRIMARY KEY,
  lead_id VARCHAR(50) NOT NULL REFERENCES leads(lead_id) ON DELETE CASCADE,
  telecaller_id UUID NOT NULL REFERENCES users(user_id),
  call_timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
  call_outcome VARCHAR(30) NOT NULL CHECK (call_outcome IN ('Answered','Unanswered','Invalid Number','Requested Callback','Not Interested')),
  followup_notes TEXT NOT NULL
);
CREATE INDEX calls_lead ON call_logs (lead_id, call_timestamp);
CREATE INDEX calls_employee_day ON call_logs (telecaller_id, call_timestamp);
CREATE TABLE field_visits (
  visit_id UUID PRIMARY KEY,
  lead_id VARCHAR(50) NOT NULL REFERENCES leads(lead_id) ON DELETE CASCADE,
  field_employee_id UUID NOT NULL REFERENCES users(user_id),
  requested_by UUID NOT NULL REFERENCES users(user_id),
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  request_notes TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'REQUESTED' CHECK (status IN ('REQUESTED','COMPLETED')),
  entry_date DATE,
  address_visited TEXT NOT NULL DEFAULT '',
  area VARCHAR(250) NOT NULL DEFAULT '',
  contact_verified VARCHAR(30) NOT NULL DEFAULT '',
  visit_report TEXT NOT NULL DEFAULT '',
  latitude DOUBLE PRECISION CHECK (latitude BETWEEN -90 AND 90),
  longitude DOUBLE PRECISION CHECK (longitude BETWEEN -180 AND 180),
  completed_at TIMESTAMPTZ,
  CHECK ((latitude IS NULL) = (longitude IS NULL))
);
CREATE UNIQUE INDEX one_open_visit_per_lead ON field_visits (lead_id) WHERE status = 'REQUESTED';
CREATE INDEX visits_employee ON field_visits (field_employee_id, status);
CREATE TABLE lead_events (
  event_id UUID PRIMARY KEY,
  lead_id VARCHAR(50) NOT NULL REFERENCES leads(lead_id) ON DELETE CASCADE,
  actor_id UUID NOT NULL REFERENCES users(user_id),
  event_type VARCHAR(50) NOT NULL,
  detail JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX lead_events_timeline ON lead_events (lead_id, created_at);
CREATE TABLE audit_logs (
  audit_id UUID PRIMARY KEY,
  actor_id UUID REFERENCES users(user_id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  target VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE app_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  college_name VARCHAR(150) NOT NULL DEFAULT 'Shastra Jr College',
  timezone VARCHAR(100) NOT NULL DEFAULT 'Asia/Kolkata'
);
INSERT INTO app_settings (id) VALUES (1);
CREATE TABLE session (
  sid VARCHAR NOT NULL PRIMARY KEY,
  sess JSON NOT NULL,
  expire TIMESTAMP(6) NOT NULL
);
CREATE INDEX session_expire ON session (expire);

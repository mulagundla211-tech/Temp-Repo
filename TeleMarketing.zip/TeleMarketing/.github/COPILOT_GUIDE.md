# Copilot agents and skills for Shastra CRM

This workspace includes six custom agents, seven reusable skills, and shared [repository instructions](copilot-instructions.md). They support development of the existing application; they are not runtime AI agents, admission chatbots, or Microsoft Foundry resources.

## Use in VS Code

1. Open the application root folder in VS Code with GitHub Copilot enabled and workspace trust granted only if you trust this project.
2. Open Chat and select an agent from the agent picker. Choose the role below that fits the task.
3. Give a concrete outcome and constraints. Reference application files or requirements as needed.
4. Skills are discovered from `.github/skills/<name>/SKILL.md` and can be loaded by relevance. Where supported by your VS Code version, type `/` and select a skill by its name to invoke it explicitly.
5. Handoff buttons suggest a next agent; they do not automatically run it. Review the generated prompt before sending it.

If entries are missing, reload the VS Code window, check that this folder is the workspace root, and inspect **Chat: Configure Custom Agents** / **Chat: Configure Skills** where available. Check the installed VS Code/Copilot version's customization diagnostics/settings rather than installing an unrelated agent framework.

No model is pinned; agents use your selected model. Planner and reviewer explicitly allow only read/search tools. Implementation, QA and operations agents omit a fixed tool list so available local tools (including optional browser tools) can be selected in your environment. Review those enabled tools and normal approval prompts before use. Markdown instructions are guidance, not a security sandbox.

## Agents

| Agent | Use for | Main skills |
|---|---|---|
| [crm-planner](agents/crm-planner.agent.md) | Read-only requirement analysis, acceptance criteria, change design | Feature planning |
| [crm-backend](agents/crm-backend.agent.md) | REST/auth, role-scoped workflows, SQL/reporting, account/CSV operations | API workflows, PostgreSQL migrations |
| [crm-frontend](agents/crm-frontend.agent.md) | Bootstrap design, accessible forms, role navigation, mobile visits | Responsive UI |
| [crm-qa](agents/crm-qa.agent.md) | Regression tests, actual database behavior, browser acceptance | Verification |
| [crm-operations](agents/crm-operations.agent.md) | Local setup/build/run, configuration, approved deployment | Local operations, migrations |
| [crm-reviewer](agents/crm-reviewer.agent.md) | Read-only correctness, role/privacy and regression review | Access review |

## Skills

| Skill / slash command | Procedure |
|---|---|
| [crm-feature-planning](skills/crm-feature-planning/SKILL.md) | Map a requirement to actors, data flow, acceptance criteria and rollout |
| [crm-api-workflows](skills/crm-api-workflows/SKILL.md) | Wire strict validation, role/ownership checks, transactions, history and reports |
| [crm-postgres-migrations](skills/crm-postgres-migrations/SKILL.md) | Evolve schema and explicitly wire new migrations; verify clean and upgrade paths |
| [crm-responsive-ui](skills/crm-responsive-ui/SKILL.md) | Implement mobile/desktop workflows with safe rendering and useful failure states |
| [crm-verification](skills/crm-verification/SKILL.md) | Select and run focused checks; report passed/failed/blocked/not-run evidence |
| [crm-local-operations](skills/crm-local-operations/SKILL.md) | Configure local services, diagnose install/startup and prepare safe deployment |
| [crm-access-review](skills/crm-access-review/SKILL.md) | Trace access, disclosure, concurrency and accountability for sensitive changes |

## Example requests

Select **crm-operations** for the current local-verification task:

> Check npm access and configuration presence without printing secrets. Build the application, confirm the dedicated PostgreSQL target before migrations, and start it locally. Verify health and tell me what is still blocked.

Select **crm-planner** for a new feature:

> Plan a scheduled campus appointment workflow. Map every affected role, schema field, route, form and report. Ask before changing existing access policies. Do not implement yet.

Select **crm-backend** for a focused defect:

> Fix the follow-up boundary defect using the college timezone. Preserve chronological order and lost/admitted exclusions. Add exact timestamp and cross-user regression tests.

Select **crm-frontend** for UX work:

> Improve field visit entry at 390px width without exposing the telecalling finance form. Preserve form values on errors and make optional GPS failure clear.

Select **crm-qa** for acceptance:

> Verify call logging, stale-version conflicts and visit completion using a confirmed disposable PostgreSQL test database. Report actual assertions and blocked checks.

Select **crm-reviewer** for read-only review:

> Review the changed CSV import/export implementation for role scoping, all-or-nothing writes, formula handling and missing regression tests. Do not edit files or execute commands.

## Suggested workflow

For a cross-cutting feature: planner -> relevant implementer -> QA -> reviewer. Use operations only when setup or rollout needs it. Small tasks can stay with one agent. Agent selection does not automatically delegate work, create tasks, install dependencies, migrate a database or deploy infrastructure.

Shared rules preserve:

- The five-role access model and assigned student/visit boundaries.
- Exact campus-local follow-up ordering and derived call counts.
- Transactional writes, explicit concurrency conflicts and audit accountability.
- Current portfolio versus period activity reporting definitions.
- Student-data privacy and private environment configuration.
- Honest runtime verification rather than success claims based on generated code.

## Maintenance and validation

- Keep descriptions specific so the right skill is selected. Skill names must match directory names and use lowercase letters/numbers/hyphens.
- Keep agent files as `*.agent.md` in `agents`; keep this guide outside that folder so it is not detected as another agent.
- Keep `SKILL.md` at the root of each skill directory. Use portable relative Markdown links, and OS-appropriate shell commands inside procedures.
- When the schema, routes, npm scripts or permission matrix change, update affected skills as well as application documentation.
- Keep handoff targets aligned with agent names and leave `send: false` for user-controlled transitions.
- Validate YAML frontmatter, local links, directory/name matching and handoff targets after customization changes. Application tests are unnecessary for documentation-only edits.
- Check actual picker/skill discovery in your VS Code installation. Static file validation does not prove extension loading or application readiness.

Creating these files does not resolve the application's earlier package/database verification blockers or certify its runtime. Use the operations and QA procedures to recheck the current environment.

## Format references

- [VS Code custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents)
- [VS Code agent skills](https://code.visualstudio.com/docs/agent-customization/agent-skills)
- [Application requirements](../RequirementDetails.md)
- [Application setup and architecture](../README.md)

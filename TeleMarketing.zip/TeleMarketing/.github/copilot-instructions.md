# Shastra Admissions CRM: repository guidance

## Start with evidence

- Read [requirements](../RequirementDetails.md) for intended behavior and [README](../README.md) for the implemented architecture and setup. Confirm current behavior in code; documentation is not proof that a feature works.
- Preserve the current stack: TypeScript/Express REST API, PostgreSQL, HTML5, locally served Bootstrap 5, and vanilla JavaScript. Do not introduce a framework, ORM, external service, or different database without an agreed reason.
- Ask before changing access policy, reporting definitions, retention, external integrations, or deployment targets.
- Use the [customization guide](COPILOT_GUIDE.md) to choose a focused agent or skill. A small change does not need multiple agents.

## Source map

| Surface | Source |
|---|---|
| Validation, roles, statuses, dispositions, CSV escaping | [src/domain.ts](../src/domain.ts) |
| Authentication, REST routes, permissions, reporting, audit | [src/app.ts](../src/app.ts) |
| PostgreSQL pool and transactions | [src/db.ts](../src/db.ts) |
| Schema and migration runner | [migrations/001_initial.sql](../migrations/001_initial.sql), [src/migrate.ts](../src/migrate.ts) |
| Startup and first SuperAdmin | [src/server.ts](../src/server.ts), [src/bootstrap.ts](../src/bootstrap.ts) |
| UI, routing, forms, API client | [public/app.js](../public/app.js), [public/index.html](../public/index.html), [public/styles.css](../public/styles.css) |
| Automated checks | [package.json](../package.json), [tests/domain.test.ts](../tests/domain.test.ts), [tests/integration.test.ts](../tests/integration.test.ts) |
| Deployment | [Dockerfile](../Dockerfile), [compose.yaml](../compose.yaml), [.env.example](../.env.example) |

## Access and data invariants

- Staff can access only their assigned leads; Staff-created leads belong to their creator. Check ownership on the server for both reads and writes.
- OnField gets assigned visits and the limited student-contact projection needed for outreach, not unrestricted telecalling/financial records.
- Management is read-only and aggregate-only. Admin manages operational data and Staff/OnField accounts, not privileged accounts. SuperAdmin performs technical administration and audited corrections.
- Derive actor identity and role from the authenticated active account, never from request fields. Preserve session invalidation, CSRF, cookie protections and password hashing.
- Status values are `HOT`, `WARM`, `CALLBACK`, `PENDING`, `LOST`; admission confirmation is a separate flag.
- `callno` is derived from actual call records. Dialing a `tel:` link must not increment it.
- Follow-up date and time are paired local values in the configured college timezone. Due means the exact scheduled timestamp is now or earlier; exclude admitted/lost leads.
- Keep call insertion, lead status/schedule changes and journey events transactional. Preserve row locks, version checks and explicit HTTP 409 conflicts.
- Only one open field visit per lead; duplicate completion must not succeed. GPS is optional and consent-based, not proof of address proximity.
- Keep journey/audit accountability. Technical corrections require a reason; do not silently rewrite historical events.
- Current portfolio totals are not period activity. Quoted fees are not revenue; confirmations are not net admissions. Preserve these labels in SQL, API, UI and tests.
- CSV imports create new leads atomically; CSV exports protect against spreadsheet formulas. Do not infer duplicate students solely from a shared parent phone number.

## Implementation discipline

- Trace the affected form, validator, endpoint, SQL, reporting and tests before editing. Reuse existing helpers and error handling.
- Use strict request validation and parameterized SQL. Never weaken types with `any` just to make a build pass.
- Escape untrusted text/attributes in UI templates. Use the existing API/form/notification helpers; make failures visible without erasing entered data.
- Keep fixed checklist booleans unless a schema change is approved. JSONB currently stores journey details, not a configurable checklist engine.
- The migration runner currently explicitly loads version 1. Adding a new SQL file alone does not execute it. For an existing database, add and wire a forward migration; do not reset tables or rewrite applied history.
- Preserve unrelated work. Make targeted changes, update affected documentation, and avoid unnecessary new tools or dependencies.

## Validation and operating safety

- Read the current npm scripts before running commands. Use `npm run check`, `npm run build`, and the smallest relevant test selection.
- Domain tests use Node's test runner through `tsx`. Integration tests require real PostgreSQL and a separate disposable `TEST_DATABASE_URL`.
- Integration cleanup drops its uniquely named test schema. Verify database identity, not merely different URL text: aliases, credentials or query parameters can still reach the same database.
- Never use production student data in test fixtures, screenshots, prompts or external tools. Use synthetic families and approved test accounts.
- Keep real secrets in ignored local configuration or deployment secrets. Do not print `.env`, credential-bearing URLs, npm authentication configuration, or rendered Compose secrets.
- Do not disable TLS verification or globally change registry settings to bypass installation failures. Report the exact blocker and request approved credentials/connectivity.
- On Windows, use PowerShell and backslash-separated shell paths; Markdown links use portable relative paths.
- Ask before production migrations, destructive actions, account bootstrap, publishing ports, or cloud provisioning. Do not delete data volumes as a troubleshooting step.
- Only claim a build, test, browser flow or deployment passed after observing its result. Distinguish passed, failed, blocked and not run. Historical blockers in the README must be rechecked, not assumed permanent.

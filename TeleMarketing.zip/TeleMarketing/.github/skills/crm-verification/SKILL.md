---
name: crm-verification
description: Verify Shastra CRM changes using TypeScript checks, Node/tsx domain tests, Supertest with real PostgreSQL, and browser acceptance. Use for build validation, regression tests, role/concurrency checks or local end-to-end verification.
---

# Verify the actual CRM behavior

## Prerequisites

Read [npm scripts](../../../package.json), [domain tests](../../../tests/domain.test.ts), [integration tests](../../../tests/integration.test.ts), and the changed implementation.

Confirm dependencies are installed. For integration tests, require `TEST_DATABASE_URL` for a separate disposable database with schema create/drop permission. Do not display the value. The suite's URL equality guard is not a complete identity check: different URLs may address the same database. Obtain confirmation of isolation before running.

Tests create a unique `crm_test_*` schema, run migrations, generate synthetic accounts and drop that schema afterwards. Do not broaden cleanup if a run fails.

## Choose the smallest useful check

| Change | Initial verification |
|---|---|
| Documentation/agent instructions | Check metadata, references and source accuracy; no application build needed |
| Browser JavaScript only | `node --check public\app.js`, then affected browser workflow |
| Domain validation/helper | `npm run test:unit` and `npm run check` |
| API/ownership/transaction/report/schema | Targeted integration file or names, then `npm run check` |
| Packaging/startup/cross-cutting release | `npm run build`, full relevant suite, `/health`, real startup/browser flow |

Commands available in this repository:

```powershell
npm run check
npm run build
npm run test:unit
npm exec -- tsx --test --test-concurrency=1 --test-name-pattern="queue|call attempts" tests\integration.test.ts
npm test
```

Use the name filter only when those named behaviors are relevant. Do not run every command for a small change. Integration commands require the confirmed test database; blocked setup is not a passing test.

## Required evidence by workflow

| Workflow | Positive and negative assertions |
|---|---|
| Auth/accounts | Valid login/logout; anonymous/CSRF denial; deactivation/session invalidation; Admin cannot grant privileged roles |
| Lead scope | Assigned Staff succeeds; another Staff is denied on read/write; Management cannot retrieve contacts |
| Calls/concurrency | One call and matching event; two writes with the same version yield one success/one conflict; no partial writes |
| Queue | Before/equal/after boundary, paired date/time, campus timezone, chronological order, lost/admitted exclusions |
| Visits | Assigned agent only; unique open request; one completion; invalid/future report rejected; optional GPS pair validation |
| Admissions/reports | Explicit confirmation event; exact totals, date/cohort attribution, reversal behavior and no one-to-many double counting |
| CSV | Invalid row/assignee rolls back all rows; header/type validation; formula-neutralized cells; role/size/count limits |
| Schema | Fresh install, upgrade with existing data, rerun idempotence, constraints and failed migration rollback |

Do not imply every row is already covered by existing tests. Inspect actual assertions and add the missing ones needed for the change.

## Browser acceptance

With approved synthetic users: sign in as each affected role, execute the workflow, reload, and verify persisted values plus denied actions. Check 390px/1440px layouts, keyboard labels/focus, dialog errors, empty states and console/network failures. Use actual API behavior, not mocked success responses, for end-to-end claims.

## Results

Report `Passed`, `Failed`, `Blocked` or `Not run` per check with the command/action and evidence. Include counts, relevant failures, data cleanup status and environment prerequisites. A static syntax check, a mock database or HTTP 200 from the login page cannot certify PostgreSQL workflows or a 50-user load target.

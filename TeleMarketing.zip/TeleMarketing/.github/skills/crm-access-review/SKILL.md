---
name: crm-access-review
description: Review Shastra CRM role boundaries, student-data privacy, request validation, audit trails and concurrent workflow correctness. Use when reviewing sensitive changes to authentication, leads, accounts, visits, reporting or CSV access.
---

# Access and correctness review

## Scope and evidence

Read [role requirements](../../../RequirementDetails.md), [implemented access model](../../../README.md), [API](../../../src/app.ts), [domain rules](../../../src/domain.ts), and the affected tests.

This is a review workflow, not authorization to modify data or run live attacks. Use static evidence or explicitly authorized local tests with synthetic data. Do not read/print secrets or student exports to illustrate a finding.

## Trace each affected entry point

1. Identify the trusted actor source and session/CSRF requirements.
2. Check both role authorization and per-record ownership for reads and writes.
3. Inspect response fields, errors and exports for unnecessary disclosure.
4. Verify validation, SQL binding and escaping at their respective boundaries.
5. Follow transaction, lock, conflict and rollback paths.
6. Check journey/audit attribution and resulting counts.
7. Compare assertions with the real failure path, including cross-user requests.

## Application-specific checklist

- Staff cannot bypass assignment via lists, detail URLs, calls, visit requests, exports or manipulated payloads.
- OnField cannot open another employee's visits or receive unrestricted financial profiles. Confirm intended historical access separately from pending-visit queues.
- Management remains aggregate-only; no hidden endpoint leaks contacts.
- Admin cannot create, promote, edit or deactivate privileged accounts. Self-deactivation/role-change and last-SuperAdmin safeguards must survive concurrent requests.
- Session regeneration, active-account checks, expiry, password hashing, CSRF, cookie policy and session invalidation remain effective.
- User-controlled SQL values are bound; UI templates and CSV cells have context-appropriate protection.
- Concurrent lead/call/assignment operations do not lose writes. Active assignee checks and user deactivation cannot strand new work.
- Unique open-visit and single-completion guarantees remain enforced under concurrency.
- Corrections and deletions preserve the documented audit trail and cannot be used by ordinary operators.
- CSV limits and atomicity are enforced on the server; reporting queries scope cohorts before aggregating.
- Test/configuration logs do not expose connection strings, session tokens, passwords, GPS or student data.

## Report

Give actionable findings with severity, location, affected actor, prerequisites, a concrete failure path, impact, confidence and a regression test recommendation. Distinguish confirmed defects from unanswered policy questions.

Do not present hypothetical risks as verified vulnerabilities or claim an exhaustive security certification. If there are no findings, report the reviewed scope and what was not executed. Request agreement before implementing fixes outside the original task.

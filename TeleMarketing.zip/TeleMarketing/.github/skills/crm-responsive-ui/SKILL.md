---
name: crm-responsive-ui
description: Implement and validate Shastra HTML5/Bootstrap interfaces for dashboards, lead entry, follow-ups, mobile field visits, accounts, imports and settings. Use for visual design, accessibility, form behavior or browser/API integration changes.
---

# Responsive CRM interface

## Existing surfaces

Read [HTML shell](../../../public/index.html), [browser logic](../../../public/app.js), [styles](../../../public/styles.css), and the relevant [API route](../../../src/app.ts).

The application uses hash routes and shared render/form/action helpers, not React or a frontend bundler. Preserve locally served Bootstrap, system fonts and the existing green-and-sage design unless a redesign is requested.

## Procedure

1. Identify the user role, task and mobile/desktop entry point. Read the current API response and submit payload before editing fields.
2. Reuse `api`, `escape`, `field`, `check`, `modal`, `notify`, `formActions`, `actions` and existing route/page patterns.
3. Update rendering, form serialization, submit behavior, role visibility and any related table/report together.
4. Handle loading, empty, validation, network, expired-session and version-conflict states explicitly. Preserve entered values after a failed save and provide a deliberate reload/retry path.
5. Prevent double submissions. Keep route/navigation guards so slower requests do not overwrite a newer screen.
6. Escape dynamic text/attributes and constrain links. Do not disable CSP or introduce inline script handlers/remote CDNs.
7. Provide labels, appropriate input types, required indicators, keyboard operation, visible focus, modal title/focus behavior and readable error announcements.
8. Check small-screen overflow, table scrolling, navigation collapse and touch-sized actions.

## Screen-specific acceptance

- **Dashboard:** Correct role scope; explicit live snapshot versus selected-period labels; meaningful empty data rather than fake chart values.
- **Lead entry:** Profile, academics, source/counselling, fees, schedule and checklist persist after reload. Optional blanks remain distinct from numeric zero.
- **Follow-ups:** Scheduled order and campus timezone are visible; filters/pagination retain query state; unscheduled records are not represented as due.
- **Caller control:** Parent/student links use `tel:`. Call count changes only after logging a successful attempt.
- **Field visits:** Briefing, family/contact/address and objections are visible without the full finance form. GPS denial/timeout does not prevent submission.
- **Team/data/settings:** UI matches backend roles, destructive actions need confirmation, imports show actual failures, downloads preserve privacy warnings.

## Verification

Run `node --check public\app.js` for a frontend-only syntax change, or `npm run check` for cross-layer changes. Neither proves the interface works.

Using available browser tools and synthetic test accounts, check at least 390px and 1440px viewport widths, keyboard navigation, server-side validation failure, session expiry and reload persistence. Inspect console/network errors as well as screenshots.

The repository does not currently declare a browser-test runner. Do not invent a passing Playwright run or install a new framework solely for a cosmetic edit. Use [verification](../crm-verification/SKILL.md) to report observed coverage and blockers.

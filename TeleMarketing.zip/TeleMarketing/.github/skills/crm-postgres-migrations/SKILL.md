---
name: crm-postgres-migrations
description: Safely evolve or debug Shastra PostgreSQL schema, constraints, indexes, transactions and migrations. Use for new persistent fields, reporting SQL changes, concurrency bugs, migration failures or schema rollout.
---

# PostgreSQL changes and migrations

## Current implementation

Read [schema](../../../migrations/001_initial.sql), [runner](../../../src/migrate.ts), [pool/transactions](../../../src/db.ts), and [integration setup/cleanup](../../../tests/integration.test.ts).

The runner explicitly reads `001_initial.sql` and records version `1` under a transaction advisory lock. It does not discover arbitrary numbered SQL files. A new file alone will not be applied.

## Safe workflow

1. Establish whether the request is design-only, a disposable/local migration, or a deployed-database change. Confirm the target privately before any writes.
2. Inventory affected columns, foreign keys, indexes, API validation, UI inputs, exports and reporting queries.
3. Preserve an already applied migration. Add a forward version and extend the runner to execute unapplied versions in order and record them transactionally.
4. Plan existing-row defaults/backfills and constraint validation before making a field required. Avoid table resets, data loss, and silent coercion.
5. Retain the migration lock so concurrent startup cannot apply the same version twice. Handle SQL that cannot run transactionally explicitly rather than silently removing transaction protection.
6. Test a clean database and an upgrade from the previous version with representative data; rerun migrations to verify no repeat effects.
7. Check foreign-key/history behavior, rollback, version conflicts and indexes for changed filters. Use synthetic data for query plans; obtain approval before analyzing sensitive/live data.
8. Document deployment order, expected lock duration, backup requirement and recovery procedure. Do not promise a destructive down migration is safe.

## Preserve these properties

- UUID account/activity IDs and string lead IDs are not interchangeable.
- Lead assignment supports Staff scoping and date/time queue lookup.
- `next_followup_date` and `next_followup_time` are paired local calendar values; event timestamps are timezone-aware.
- The custom PostgreSQL DATE parser returns strings; avoid host-timezone conversion.
- Monetary values use decimal database types; preserve null versus zero and test precision when crossing JavaScript boundaries.
- Call/visit relationships are one-to-many. Avoid aggregate duplication when joining both.
- The partial unique visit index prevents multiple `REQUESTED` visits for one lead.
- Lead version locking and active-assignee checks protect concurrent workflows.
- Journey detail is JSONB; checklist booleans are separate current-state columns.
- User history foreign keys restrict deletion; lead deletion cascades to its histories while a separate administrative audit remains.

## Verification and safety

Run the migration command only against a confirmed target:

```powershell
npm run db:migrate
```

For test execution use [verification](../crm-verification/SKILL.md). The integration suite drops only its generated schema, but must still run against a separately confirmed disposable database. Never use a production URL, `DROP SCHEMA public`, a volume reset, or disabling constraints as a migration workaround.

Report version(s), compatibility effects, clean/upgrade/rerun results, and any unverified rollback or operational risk.

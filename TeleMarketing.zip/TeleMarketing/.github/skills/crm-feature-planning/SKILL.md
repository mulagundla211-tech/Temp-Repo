---
name: crm-feature-planning
description: Plan Shastra admissions CRM changes across student profiles, telecalling, follow-ups, field visits, dashboards, access rules and deployment. Use before cross-cutting features, ambiguous requirements, or changes to business policy.
---

# Plan an admissions CRM change

## Inputs and evidence

Read the requested outcome, [requirements](../../../RequirementDetails.md), [architecture/access model](../../../README.md), and [repository guidance](../../copilot-instructions.md). Locate current routes in [the API](../../../src/app.ts), validators in [the domain module](../../../src/domain.ts), and consumers in [the browser application](../../../public/app.js).

Do not treat the requirements as proof that every described capability exists. For example, the current checklist uses fixed booleans; GPS stores coordinates but does not geocode an address or validate proximity.

## Procedure

1. State the actor, starting screen/state, triggering action and persisted result.
2. Map the affected workflow:
   - Account sign-in, deactivation and role administration.
   - Student/family profile, academics, source, fee discussion and checklist.
   - Telecaller queue, call disposition and next follow-up.
   - Visit request, assignment, completion and feedback.
   - Admission confirmation, journey and technical correction.
   - Aggregate reporting, CSV import/export or global settings.
3. Inspect the full affected path: form -> payload -> validation -> authorization -> transaction -> response -> report/timeline -> tests.
4. Define allowed/denied roles and record scope before designing new endpoints. Do not expand Management into individual contacts without approval.
5. Decide whether the change needs a migration, API compatibility handling, backfill or rollout ordering.
6. Identify ambiguous business choices. Ask before changing data retention, deduplication rules, timezones, conversion definitions or third-party communication.
7. Produce small implementation steps and observable acceptance criteria, including failure and concurrent-user behavior.

## Acceptance template

| Actor / precondition | Action | Expected persisted result | Denied / failure behavior | Verification |
|---|---|---|---|---|
| Assigned Staff, open lead at version N | Log unanswered call and schedule next step | One call, updated schedule, journey event, advanced version | Other Staff denied; stale version conflicts; no partial writes | Integration test and UI reload |

Adapt this template rather than copying it as a claimed result.

## Deliverable

Return scope, evidence, assumptions requiring approval, touched surfaces, ordered work, migration/recovery considerations, and the test plan. Link to [API workflows](../crm-api-workflows/SKILL.md), [UI](../crm-responsive-ui/SKILL.md) or [operations](../crm-local-operations/SKILL.md) only as relevant next steps.

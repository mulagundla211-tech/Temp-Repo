---
name: crm-local-operations
description: Build, configure, run and diagnose Shastra CRM locally, or prepare approved Docker/VPS/Coolify deployment. Use for npm authentication/TLS errors, .env setup, PostgreSQL connectivity, bootstrap, health checks and startup failures.
---

# Build and operate Shastra CRM

## Establish scope

Read [setup guide](../../../README.md), [scripts](../../../package.json), [environment template](../../../.env.example), [startup](../../../src/server.ts), [Dockerfile](../../../Dockerfile) and [Compose](../../../compose.yaml).

Determine local/test versus staging/production. Check current prerequisites; old README blockers may no longer apply. This skill does not authorize production writes, cloud provisioning or installing a machine-wide database server.

## Local procedure

1. Check Node/npm availability and configured npm registry without dumping authentication configuration. Node 20.14+ is required; the image uses Node 22.
2. If dependencies are missing, use `npm ci` with a valid lockfile, otherwise `npm install`. Keep the generated lockfile and report install failures explicitly.
3. Preserve an existing `.env`. If absent, copy the template without overwriting:

   ```powershell
   if (!(Test-Path .env)) {
       Copy-Item .env.example .env
   }
   ```

4. Have the user set `DATABASE_URL`, a random `SESSION_SECRET` of at least 32 characters, and private initial-account settings in local configuration. Never request passwords in chat or log URLs. Integration tests need a separate disposable `TEST_DATABASE_URL`.
5. For local HTTP use `COOKIE_SECURE=false` and `TRUST_PROXY=0`. Preserve required provider TLS settings and URL-encoded credentials.
6. Confirm a dedicated application database before running `npm run db:migrate`. For schema changes use [migration guidance](../crm-postgres-migrations/SKILL.md).
7. Run `npm run db:bootstrap` only if creating the first SuperAdmin is requested. It refuses to run if one exists. Do not overwrite an existing admin or invent a default password; remove bootstrap secrets after use.
8. Run `npm run check`, `npm run build` and relevant [tests](../crm-verification/SKILL.md). Fix verified code failures, not missing-environment symptoms.
9. Start `npm start` for the compiled application or `npm run dev` for development. Check the actual chosen port and verify:

   ```powershell
   Invoke-RestMethod http://localhost:3000/health
   ```

10. Verify the page, local Bootstrap assets, sign-in and persistence using authorized test data. A health response proves neither role correctness nor all user workflows.

If a process is started, track its PID/session, check responsiveness, and give a stop/restart procedure. Do not kill unrelated processes or detach a server beyond the session unless requested.

## Bounded troubleshooting

| Failure | Action |
|---|---|
| npm E401 | Ask for approved registry credential refresh in this environment; retry after confirmation |
| TLS handshake/certificate error | Check approved network/proxy/certificate configuration; never disable TLS verification |
| Missing `tsc` / `tsx` | Restore declared dependencies; do not globally install random tool versions |
| Database refused/unreachable | Check host/port, service and network access without displaying credentials |
| Missing tables/version | Confirm database identity, then apply approved migrations; do not reset it |
| Login cookie absent locally | Check local HTTP cookie settings and proxy count; retain production secure settings |
| Port occupied | Identify ownership; choose/confirm another port rather than killing an unrelated process |

Stop repeated retries once the same external blocker is established. Report the missing prerequisite and safe next action.

## Docker and production preparation

- Compose uses `db` as the container database hostname; local host-run Node uses the actual local/remote database hostname.
- Database storage is persistent and the database network is internal. Do not publish PostgreSQL or delete its volume for troubleshooting.
- Validate with `docker compose config --quiet` to avoid printing resolved secrets.
- The application is published on loopback; TLS terminates at an approved proxy. Match `TRUST_PROXY` to the real trusted topology, not arbitrary forwarded headers.
- `.env.example` contains local HTTP settings. Explicitly set production `COOKIE_SECURE=true`; do not assume Compose defaults override existing `.env` values.
- The image runs migrations at startup. Confirm backups, rollout ordering and target before deployment.
- Verify health, logs, static assets and user workflows after an approved deployment. Do not claim Coolify routing, backups or load capacity are configured merely because a Compose file exists.

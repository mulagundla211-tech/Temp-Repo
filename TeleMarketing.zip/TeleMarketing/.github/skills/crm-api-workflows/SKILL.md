---
name: crm-api-workflows
description: Implement or debug Shastra Express APIs for authentication, five-role access, leads, call dispositions, follow-up queues, field reports, dashboard calculations, CSV operations and account administration.
---

# Implement a CRM API workflow

## Read first

- [Domain validation and role helpers](../../../src/domain.ts)
- [Routes, permissions, reporting and errors](../../../src/app.ts)
- [Transaction helper](../../../src/db.ts)
- [Integration fixtures and assertions](../../../tests/integration.test.ts)
- [Repository invariants](../../copilot-instructions.md)

## Procedure

1. Read the affected route and browser payload. Preserve full-save versus partial-update semantics deliberately; do not let schema defaults erase fields in a new PATCH workflow.
2. Validate untrusted data with strict Zod schemas. Use the existing enums, date validation, numeric limits, UUID validation and paired follow-up checks.
3. Authenticate first; restrict roles with `allow` and records with ownership-scoped SQL or `accessibleLead`. Never accept actor IDs or elevated roles from the client.
4. Reuse `transaction`, `checkVersion`, `event`, `audit` and `assignee` where appropriate. Validate active assignees and their roles.
5. Use parameterized values and allowlisted query structure. Keep conflict/not-found/validation responses in the existing `{ error }` format.
6. Update the UI contract and focused tests together. Read routes, including static paths before `:id`, to avoid accidental shadowing.

## Workflow checks

| Area | Required behavior |
|---|---|
| Authentication | CSRF token before login/write; regenerated login session; active account lookup; finite session lifetime; invalidation on account change |
| Accounts | Admin cannot create/manage privileged roles; own-account and last-SuperAdmin safeguards; reassignment before role/deactivation changes |
| Lead updates | Staff ownership; optimistic version; atomic edits/history; admission flag independent of lead temperature |
| Calls | One persisted record per successful attempt; derived `callno`; required notes; callback schedule; no records left by rejected stale writes |
| Follow-ups | Paired local date/time, campus timezone, exact due timestamp, stable chronological ordering, lost/admitted excluded |
| Field visits | Assigned OnField access, one open request, atomic single completion, optional paired/range-checked coordinates |
| Corrections | SuperAdmin-only, explicit reason, appended audit/journey accountability |
| CSV | Admin/SuperAdmin only; strict columns/values; all-or-nothing import; formula-safe export; enforced size/count limits |

## Reporting changes

Identify the exact cohort and attribution before editing queries:

- Portfolio and checklist values are current snapshots.
- Calls and completed visits use event timestamps within campus-local date bounds.
- Admission confirmations are activity, not net admissions; daily and period distinct counts can differ.
- Average conversion duration uses first confirmation for currently confirmed leads.
- Staff and OnField scope must apply even to aggregates. Management receives no student contacts.

Test numeric results with a small dataset, timezone boundaries and a later confirmation reversal. Avoid sums inflated by joins between multiple one-to-many histories.

## Completion

Use [verification](../crm-verification/SKILL.md). A passing happy-path request is insufficient: include a denied role/foreign owner, invalid payload, stale version or duplicate completion, and transaction rollback where relevant. If schema changes are needed, load [migrations](../crm-postgres-migrations/SKILL.md).

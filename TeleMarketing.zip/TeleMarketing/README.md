# Shastra Admissions CRM

A responsive admission lead-management application for Shastra Jr College, built from [RequirementDetails.md](RequirementDetails.md).

## Architecture and design

- **Frontend:** HTML5, locally served Bootstrap 5, and vanilla JavaScript. No CDN, external fonts, or third-party analytics. Responsive sidebar, green-and-sage dashboard, accessible forms, and mobile-first visit cards.
- **Backend:** Node.js, TypeScript, Express REST API, Zod request validation.
- **Database:** PostgreSQL 16+, parameterized SQL and versioned transactional migrations.
- **Authentication:** PostgreSQL-backed sessions, bcrypt password hashes, HttpOnly/SameSite cookies, CSRF tokens, login throttling, eight-hour absolute session lifetime.
- **Deployment:** Multi-stage, non-root Docker image; separate PostgreSQL container and persistent volume. Database has no published port.

The frontend and API have separate responsibilities but are served from one application container and origin. This avoids unnecessary CORS configuration and an extra proxy service. PostgreSQL remains a separate component.

### Access model

| Capability | Staff | OnField | Management | Admin | SuperAdmin |
|---|---|---|---|---|---|
| Dashboard | Own portfolio/activity | Own assigned outreach | Team aggregates | Team | Team |
| Student profiles | Assigned leads only | Limited contact/address projection for assigned visits | No individual records | All | All |
| Create/edit leads; log calls | Own queue | No | No | Yes | Yes |
| Request a home visit | Own leads | No | No | Yes | Yes |
| Complete visits | No | Assigned visits only | No | Yes | Yes |
| Assign/reassign work | No | No | No | Yes | Yes |
| Import/export | No | No | No | Yes | Yes |
| Manage users | No | No | No | Staff/OnField only | All roles |
| Delete leads; correct/delete history | No | No | No | No | Yes, audited |
| Global settings / administrative audit | No | No | No | No | Yes |

These restrictions are enforced by the API, not just hidden navigation. Inactive users are denied on their next request. Account updates invalidate existing sessions. Users with assigned leads or open visits must have their work reassigned before deactivation or role changes.

### Data integrity

The required profile fields are in `leads`; `assigned_to`, `created_by`, `address`, timestamps and an optimistic `version` were added to support governance and field workflows. `callno` is calculated from call records and cannot be manually inflated.

- Lead saves, calls and reassignments lock the row and check the displayed version. A stale save returns HTTP 409 rather than overwriting another employee's work.
- Every call disposition and its next-step update are one transaction.
- Follow-up date and time must be provided together. The **due** queue uses the exact campus-local scheduled timestamp, not just today's date. It excludes lost and admitted leads, and is sorted chronologically. Upcoming and unscheduled views are also available.
- Visit requests are assigned to active OnField accounts. Only one open visit is allowed per lead. Completion is atomic and cannot be submitted twice.
- Journey entries are append-only. SuperAdmin corrections/deletions of operational call/visit records add explicit history events; they do not rewrite past events. Deleting a lead removes its journey, calls and visits, but leaves an administrative deletion audit.
- Historical user references prevent deletion; deactivate the account instead.
- CSV imports create **new** leads and are all-or-nothing. Exported snapshots are not intended for direct re-import: remove `lead_id`, normalize protected spreadsheet cells, and verify values first. Imports deliberately do not infer duplicates from phone numbers because siblings may share a parent's number.

## Local setup

### Copilot development support

Workspace-specific agents and skills are available for planning, backend/database changes, responsive UI, verification, operations, and read-only review. See the [Copilot usage guide](.github/COPILOT_GUIDE.md) for agent selection, skill commands and example requests.

Shared conventions are in [Copilot repository instructions](.github/copilot-instructions.md). These files guide development; they do not install dependencies, configure PostgreSQL, or verify the running application.

### Prerequisites

- Node.js 20.14+ (Node.js 22 LTS recommended) and npm.
- PostgreSQL 16+ with a database/user dedicated to this application.
- Working access to your configured npm registry.

From the project directory in PowerShell:

```powershell
Copy-Item .env.example .env
npm install
```

Keep the generated `package-lock.json` with the project after the first successful install. The container uses `npm ci` when a lockfile exists; without one it resolves dependencies with `npm install`. Do not promote an unverified, unlocked build to production.

Edit `.env`:

1. Set `DATABASE_URL` to your PostgreSQL database. Percent-encode special characters in URL credentials.
2. Generate a session secret with `node -e "console.log(require('node:crypto').randomBytes(48).toString('hex'))"` and set `SESSION_SECRET`.
3. Set `BOOTSTRAP_EMAIL`, `BOOTSTRAP_USERNAME`, and a private `BOOTSTRAP_PASSWORD` of at least 12 characters (maximum 72 UTF-8 bytes).
4. For local HTTP only, use `COOKIE_SECURE=false` and `TRUST_PROXY=0`.

```powershell
npm run db:migrate
npm run db:bootstrap
npm run dev
```

Open **http://localhost:3000** and sign in with the account you just created. There are no default accounts or passwords. Bootstrap refuses to run if a SuperAdmin already exists. Remove the bootstrap password from `.env` after use.

Create Staff, OnField, Admin and Management accounts under **Team members**, then add/import leads and assign them to Staff. Staff-created leads are automatically assigned to their creator.

For a compiled local run:

```powershell
npm run build
npm start
```

The CLI tools and server load `.env`. `.env` is ignored by Git and excluded from Docker builds. Never commit credentials.

### Everyday workflows

1. **Telecaller:** Open Follow-up tracker, open a student, use a phone link, and choose **Log a call**. Select a disposition, record notes, and schedule the next call.
2. **Admissions:** Keep profile/fees/checklist current. Confirm admission with the explicit checklist item; `HOT` is not the same as admission.
3. **Escalation:** Choose **Request home visit**, select a representative, and provide a briefing.
4. **OnField:** Open the assigned visit, complete the report, optionally capture GPS, and submit. Parent concerns and the course are available without exposing financial forms.
5. **Management:** Review aggregates, employee activity, daily calls/confirmations and checklist coverage. Management cannot browse student contact lists.
6. **Admin:** Create Staff/OnField accounts, reassign leads and open visits, and import/export student profiles.
7. **SuperAdmin:** Manage all roles, configure college name/timezone, inspect audit activity, and correct/remove erroneous operational records with a reason.

### Reporting semantics

- Portfolio totals, pipeline, quoted fee value, checklist coverage and conversion rate are **current snapshots**, independent of the selected reporting date range.
- Calls and completed-visit activity are filtered by event timestamps in the configured college timezone.
- Period confirmations count distinct students confirmed by each employee in the selected range. Daily confirmations count distinct students per day. These are confirmation activity, **not net admissions**: a later reversal does not erase history.
- Average time to admission measures creation to first confirmation for currently confirmed students.
- Quoted fee value is not booked revenue or payments collected.
- GPS requires HTTPS (or localhost) and explicit browser permission. It is optional and is not an address-distance/proximity check; address geocoding is not included.

## Validation

```powershell
npm run check
npm run build
npm run test:unit
```

For integration tests, create a **separate disposable PostgreSQL database**, then set `TEST_DATABASE_URL` in `.env` or the process environment:

```powershell
$env:TEST_DATABASE_URL = "postgres://test_user:YOUR_URL_ENCODED_PASSWORD@localhost:5432/shastra_test"
npm test
```

The test account needs permission to create/drop schemas in that disposable database. Each run creates an isolated, uniquely named schema, applies migrations twice to check idempotence, and removes only that schema afterwards. Integration tests deliberately fail with a setup message if `TEST_DATABASE_URL` is absent or exactly matches `DATABASE_URL`.

Coverage includes the five-role permission matrix, CSRF/authentication, foreign-lead access denial, concurrency conflicts, call counts, exact scheduling, admission history, field-visit isolation/completion, SuperAdmin corrections, CSV rollback/formula neutralization, settings validation and logout. UI assets are checked for JavaScript syntax by `npm run check`; manual/browser verification should cover desktop and mobile widths.

## Docker / VPS / Coolify

The container tooling commands below assume Docker Compose v2.

1. Copy `.env.example` to `.env` and set strong `POSTGRES_PASSWORD`, `SESSION_SECRET`, and bootstrap credentials.
2. Set `DATABASE_URL` with the Compose service hostname **`db`**, not `localhost`, and credentials matching `POSTGRES_*`.
3. Use `COOKIE_SECURE=true` and TLS termination at the trusted reverse proxy for production. `TRUST_PROXY=1` is appropriate for exactly one trusted proxy. Restrict direct access to the application port.
4. For an HTTP-only local Docker smoke test, explicitly set `COOKIE_SECURE=false`, `TRUST_PROXY=0`. Do not use this configuration on an internet-facing production host.

```powershell
docker compose up --build -d
docker compose ps
```

The image applies migrations before the API starts. Then create the initial SuperAdmin using environment values entered in your terminal:

```powershell
$env:BOOTSTRAP_EMAIL = Read-Host "Initial SuperAdmin email"
$env:BOOTSTRAP_USERNAME = Read-Host "Initial SuperAdmin username"
$securePassword = Read-Host "Initial SuperAdmin password" -AsSecureString
$env:BOOTSTRAP_PASSWORD = [Net.NetworkCredential]::new("", $securePassword).Password
docker compose exec -e BOOTSTRAP_EMAIL -e BOOTSTRAP_USERNAME -e BOOTSTRAP_PASSWORD app node dist/bootstrap.js
Remove-Item Env:BOOTSTRAP_PASSWORD
```

Compose publishes the application only on `127.0.0.1:3000`; put your VPS reverse proxy in front of it. With Coolify, attach the application service to Coolify's proxy network and configure its domain/port 3000; let Coolify manage external routing rather than exposing PostgreSQL. Inject secrets through Coolify's environment configuration. Do not put them in the image.

`GET /health` checks the database and migration table and is used for container readiness. Monitor server error references, database connections, disk usage, and backup age.

### Production operations

- Schedule encrypted PostgreSQL backups, retain off-host copies and test restoring them to an isolated database.
- Preserve the named `postgres_data` volume across upgrades. Do not remove it to troubleshoot application errors.
- Take a backup before schema or application upgrades; run tests on a staging database.
- Configure an organization-approved student-data retention policy. Audit and journey records cannot be edited through the UI.
- Keep Docker images and npm dependencies patched. Set external reverse-proxy request/rate limits as appropriate. The built-in login limiter is per application process; multi-replica installations should add a shared edge limiter.
- Session storage is shared through PostgreSQL. Each application process uses at most 20 pool connections; size database connection capacity for the intended number of replicas. A 50-user workload has not been load-certified by these functional tests.
- Email delivery, password-reset email, WhatsApp messaging, voice/softphone providers, automated reminders, file attachments and payment collection are not part of this implementation. Click-to-call uses the device's `tel:` handler.

## API overview

All write endpoints require the session's `X-CSRF-Token`; obtain it from `GET /api/auth/me`. Errors are JSON `{ "error": "..." }`. No cross-origin API access is enabled.

| Endpoint | Purpose |
|---|---|
| `GET /api/auth/me`, `POST /api/auth/login`, `/logout`, `/password` | Authentication and password changes |
| `GET /api/dashboard?from=YYYY-MM-DD&to=YYYY-MM-DD` | Scoped aggregates and activity |
| `GET/POST /api/leads` | Paginated directory / new lead |
| `GET/PUT/DELETE /api/leads/:id` | Profile access, full validated save, technical deletion |
| `PUT /api/leads/:id/assignment` | Optimistic lead reassignment |
| `POST /api/leads/:id/calls` | Transactional call disposition + next step |
| `POST /api/leads/:id/visits` | Home visit request |
| `GET /api/visits`, `PUT /api/visits/:id/complete` | Assigned queue and report completion |
| `PUT /api/visits/:id/assignment` | Reassign an open visit |
| `PUT/DELETE /api/calls/:id`, `/api/visits/:id` | Audited SuperAdmin corrections/removal |
| `GET /api/leads/export`, `POST /api/leads/import` | CSV snapshot / atomic new-lead import |
| `GET/POST /api/users`, `PUT/DELETE /api/users/:id` | Governed account administration |
| `GET/PUT /api/settings`, `GET /api/audit` | College configuration and technical oversight |

See [src/domain.ts](src/domain.ts) for request fields and validation, [src/app.ts](src/app.ts) for routes, [migrations/001_initial.sql](migrations/001_initial.sql) for the relational schema, and [tests/integration.test.ts](tests/integration.test.ts) for executable API examples.

## Current verification status

Initial verification on the implementation machine is **blocked**:

- The configured npm feed returns `E401` even after the credential-refresh retry. Direct public registries fail TLS negotiation and cached dependencies are incomplete.
- Consequently dependency installation, lockfile generation, TypeScript compilation, and automated test execution have not completed. The build command fails because `tsc` is unavailable.
- The browser JavaScript passes `node --check`. This is syntax validation only, not an end-to-end acceptance test.
- No usable PostgreSQL executable/service or Docker CLI was found; a PostgreSQL connection is still required for migrations and integration verification.

Run the validation commands above after restoring package access and configuring PostgreSQL. This implementation should not be treated as production-verified until those checks and the browser workflow checks pass.

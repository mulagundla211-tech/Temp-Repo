const $ = (selector, root = document) => root.querySelector(selector);
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const icons = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  people: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M16 3a4 4 0 0 1 0 8"/><circle cx="9" cy="7" r="4"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  pin: '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  chart: '<path d="M4 3v17h17M8 15V9m5 6V5m5 10v-4"/>',
  phone: '<path d="m7 3 3 5-2 2a13 13 0 0 0 6 6l2-2 5 3-1 4C10 22 2 14 3 4Z"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  settings: '<circle cx="12" cy="12" r="4"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>',
  logout: '<path d="M9 5H4v14h5m5-14 7 7-7 7m-6-7h13"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  download: '<path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5"/>',
  leaf: '<path d="M20 3C8 2 2 8 5 15c7 5 16-1 15-12ZM3 21l12-12"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4"/>'
};
const icon = name => `<span class="icon" aria-hidden="true"><svg viewBox="0 0 24 24">${icons[name] || icons.grid}</svg></span>`;
let user, csrf, settings = { college_name: 'Shastra Jr College', timezone: 'Asia/Kolkata' };
let currentLead, currentVisits = [], currentUsers = [], assignees = [], navigation = 0;
const statuses = ['HOT', 'WARM', 'CALLBACK', 'PENDING', 'LOST'];
const operator = () => ['SuperAdmin', 'Admin'].includes(user.role);
const writer = () => operator() || user.role === 'Staff';
const number = value => Number(value || 0).toLocaleString('en-IN');
const money = value => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(value || 0));
const initials = name => String(name).trim().split(/\s+/).slice(0, 2).map(p => p[0]).join('').toUpperCase();
const timestamp = value => value ? new Intl.DateTimeFormat('en-IN', { timeZone: settings.timezone, dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : 'Not scheduled';
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: settings.timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const followup = lead => lead.next_followup_date ? `${lead.next_followup_date} · ${lead.next_followup_time?.slice(0, 5) || ''}` : 'Not scheduled';
const badge = lead => lead.is_admission_confirmed ? '<span class="status status-admitted">ADMITTED</span>' : `<span class="status status-${escape(lead.lead_status)}">${escape(lead.lead_status)}</span>`;
const telephone = value => value ? `<a class="text-decoration-none" href="tel:${escape(value.replace(/[^+\d]/g, ''))}">${escape(value)}</a>` : '<span class="text-muted">—</span>';
function notify(message, type = 'success') {
  const div = document.createElement('div');
  div.className = `alert alert-${type} alert-dismissible`;
  div.setAttribute('role', type === 'danger' ? 'alert' : 'status');
  div.innerHTML = `${escape(message)}<button class="btn-close" type="button" aria-label="Dismiss notification"></button>`;
  $('button', div).onclick = () => div.remove();
  $('#notifications').append(div);
  if (type === 'success') setTimeout(() => div.remove(), 6000);
}
async function api(path, options = {}) {
  const headers = { ...options.headers };
  if (options.body && typeof options.body !== 'string') {
    options.body = JSON.stringify(options.body);
    headers['Content-Type'] = 'application/json';
  }
  if (options.method && options.method !== 'GET') headers['X-CSRF-Token'] = csrf;
  const response = await fetch(`/api${path}`, { ...options, headers });
  const result = await response.json();
  if (!response.ok) {
    if (response.status === 401 && user) { user = null; loginScreen(); }
    throw new Error(result.error || 'The request failed.');
  }
  return result;
}
function empty(title, description, glyph = 'leaf') {
  return `<div class="empty-state">${icon(glyph)}<h3>${escape(title)}</h3><p>${escape(description)}</p></div>`;
}
function heading(eyebrow, title, description, actions = '') {
  return `<div class="page-heading"><div><div class="eyebrow">${escape(eyebrow)}</div><h1>${escape(title)}</h1><p class="subtitle">${escape(description)}</p></div><div class="d-flex gap-2 flex-wrap">${actions}</div></div>`;
}
const createButton = () => writer() ? `<a href="#lead/new" class="btn btn-primary">${icon('plus')} New lead</a>` : '';
function panel(title, subtitle, body, action = '') {
  return `<section class="panel"><div class="panel-header"><div><h2>${escape(title)}</h2>${subtitle ? `<p>${escape(subtitle)}</p>` : ''}</div>${action}</div>${body}</section>`;
}
function loginScreen() {
  $('#app').innerHTML = `<div class="login-layout"><aside class="login-story"><div class="brand"><div class="brand-mark">S</div><div><div class="brand-name">SHASTRA</div><small>JUNIOR COLLEGE</small></div></div><div class="login-message"><div class="eyebrow text-light">THE ADMISSIONS WORKSPACE</div><h1>Every conversation.<br>One step closer to<br><em>a brighter future.</em></h1><p>A thoughtful space to connect with families, support students, and grow our college community.</p></div><div class="login-footer">CONNECT WITH PURPOSE. GUIDE WITH CARE.</div></aside><main id="main" class="login-form-wrap"><form class="login-form" data-form="login"><div class="eyebrow">WELCOME TO SHASTRA</div><h2>Good to have you here.</h2><p class="subtitle">Sign in to your admissions workspace.</p><div class="mb-3"><label class="form-label" for="email">Work email</label><input class="form-control" id="email" name="email" type="email" autocomplete="username" placeholder="you@college.edu" required></div><div class="mb-3"><label class="form-label" for="password">Password</label><input class="form-control" id="password" name="password" type="password" autocomplete="current-password" required></div><div class="form-error" role="alert"></div><button class="btn btn-primary" type="submit">Sign in to workspace ${icon('arrow')}</button><p class="secure-note">${icon('lock')} Secure, role-based access · Contact your admin for an account</p></form></main></div>`;
}
function shell() {
  const links = [['dashboard', 'grid', 'Overview']];
  if (writer()) links.push(['leads', 'people', 'All leads'], ['followups', 'clock', 'Follow-up tracker']);
  if (operator() || user.role === 'OnField') links.push(['visits', 'pin', 'Field visits']);
  if (operator() || user.role === 'Management') links.push(['reports', 'chart', 'Performance']);
  if (operator()) links.push(['users', 'people', 'Team members'], ['data', 'download', 'Import & export']);
  if (user.role === 'SuperAdmin') links.push(['settings', 'settings', 'Settings & audit']);
  $('#app').innerHTML = `<aside class="sidebar"><a href="#dashboard" class="brand text-decoration-none text-light"><div class="brand-mark">S</div><div><div class="brand-name">SHASTRA</div><small>ADMISSIONS CRM</small></div></a><div class="nav-caption">Workspace</div><nav aria-label="Main navigation">${links.map(([route, glyph, label]) => `<a class="nav-item-link" data-nav="${route}" href="#${route}">${icon(glyph)}${label}</a>`).join('')}</nav><div class="sidebar-bottom"><button class="account-button" data-action="password" aria-label="Change your password"><div class="user-avatar">${escape(initials(user.username))}</div><div><div class="small">${escape(user.username)}</div><div class="role-tag">${escape(user.role)}</div></div></button><button class="btn btn-link text-light ps-0 mt-3" data-action="logout">${icon('logout')} Sign out</button></div></aside><div class="workspace"><header class="topbar"><div class="d-flex align-items-center gap-3"><button class="btn btn-sm btn-outline-secondary mobile-toggle" data-action="menu" aria-label="Toggle navigation" aria-expanded="false">${icon('menu')}</button><div><div class="breadcrumb-label">${escape(settings.college_name)}</div><div class="topbar-title">Admissions workspace</div></div></div><div class="topbar-right"><span class="topbar-date">${escape(new Intl.DateTimeFormat('en-IN', { timeZone: settings.timezone, weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date()))}</span><div class="user-avatar">${escape(initials(user.username))}</div></div></header><main id="main" tabindex="-1"></main></div>`;
}
function modal(title, html) {
  $('#dialogTitle').textContent = title;
  $('#dialogBody').innerHTML = html;
  bootstrap.Modal.getOrCreateInstance($('#dialog')).show();
}
const hideModal = () => bootstrap.Modal.getInstance($('#dialog'))?.hide();
const formEnd = (label = 'Save changes') => `<div class="form-error mt-3" role="alert"></div><div class="d-flex justify-content-end gap-2 mt-4"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" type="submit">${escape(label)}</button></div></form>`;
const field = (name, label, value = '', type = 'text', required = false, options = []) => {
  const attrs = `id="f-${name}" name="${name}" ${required ? 'required' : ''}`;
  let control;
  if (type === 'select' && value && !options.some(o => (Array.isArray(o) ? o[0] : o) === value)) options = [...options, [value, value]];
  if (type === 'select') control = `<select class="form-select" ${attrs}>${options.map(option => {
    const [v, text] = Array.isArray(option) ? option : [option, option || 'Select...'];
    return `<option value="${escape(v)}" ${String(value ?? '') === String(v) ? 'selected' : ''}>${escape(text)}</option>`;
  }).join('')}</select>`;
  else if (type === 'textarea') control = `<textarea class="form-control" ${attrs} rows="3" maxlength="5000">${escape(value)}</textarea>`;
  else control = `<input class="form-control" ${attrs} type="${type}" value="${escape(value)}" ${type === 'number' ? 'min="0" max="999999999" step="0.01"' : ''} ${type === 'password' ? 'autocomplete="new-password" minlength="12" maxlength="72"' : ''} ${type === 'text' ? 'maxlength="250"' : ''}>`;
  return `<div class="${type === 'textarea' ? 'col-12' : 'col-md-6'}"><label class="form-label" for="f-${name}">${escape(label)}${required ? ' *' : ''}</label>${control}</div>`;
};
function check(name, label, value) {
  return `<div class="form-check"><input class="form-check-input" type="checkbox" name="${name}" id="f-${name}" ${value ? 'checked' : ''}><label class="form-check-label" for="f-${name}">${escape(label)}</label></div>`;
}
function leadTable(items) {
  if (!items.length) return empty('A little room for new possibilities', 'No leads match this view. Add a new student or adjust your filters.', 'people');
  return `<div class="table-responsive"><table class="table"><thead><tr><th>Student / parent</th><th>Contact</th><th>Course</th><th>Status</th><th>Next follow-up</th><th>Calls</th>${operator() ? '<th>Assigned to</th>' : ''}<th><span class="visually-hidden">Actions</span></th></tr></thead><tbody>${items.map(l => `<tr><td><a href="#lead/${escape(l.lead_id)}" class="student-cell text-decoration-none"><div class="student-avatar">${escape(initials(l.student_name))}</div><div><div class="student-name">${escape(l.student_name)}</div><div class="student-sub">${escape(l.parent_name || l.location || 'Parent not provided')}</div></div></a></td><td>${telephone(l.parent_mobile || l.student_mobile)}</td><td>${escape(l.target_course || '—')}</td><td>${badge(l)}</td><td>${escape(followup(l))}</td><td>${number(l.callno)}</td>${operator() ? `<td>${escape(l.assigned_name || 'Unassigned')}</td>` : ''}<td><a class="btn btn-sm btn-outline-secondary" href="#lead/${escape(l.lead_id)}" aria-label="Open ${escape(l.student_name)}">${icon('arrow')}</a></td></tr>`).join('')}</tbody></table></div>`;
}
function pagination(data, route, query) {
  const page = Number(data.page), pages = Math.max(1, Math.ceil(data.total / data.page_size));
  const link = p => `#${route}?${new URLSearchParams({ ...Object.fromEntries(query), page: String(p) })}`;
  return `<div class="table-footer"><span>${number(data.total)} records · Page ${page} of ${pages}</span><div class="d-flex gap-2">${page > 1 ? `<a class="btn btn-sm btn-outline-secondary" href="${escape(link(page - 1))}">Previous</a>` : ''}${page < pages ? `<a class="btn btn-sm btn-outline-secondary" href="${escape(link(page + 1))}">Next ${icon('arrow')}</a>` : ''}</div></div>`;
}
function metrics(data) {
  const s = data.snapshot, calls = data.employees.reduce((sum, e) => sum + e.calls, 0), visits = data.employees.reduce((sum, e) => sum + e.visits, 0);
  const cards = user.role === 'OnField' ? [
    ['Assigned students', number(s.total), 'people', 'Your field outreach portfolio'],
    ['Visits completed', number(visits), 'pin', 'In the selected reporting period'],
    ['Hot leads', number(s.hot), 'leaf', 'Students ready for the next step'],
    ['Admissions', number(s.admissions), 'check', 'Confirmed in your portfolio']
  ] : [
    ['Total leads', number(s.total), 'people', 'Students in your admissions pipeline'],
    ['Calls made', number(calls), 'phone', data.from === data.to ? `Activity on ${data.from}` : 'In the selected reporting period'],
    ['Follow-ups due', number(s.due), 'clock', 'Scheduled for now or earlier'],
    ['Conversion rate', `${s.total ? (s.admissions / s.total * 100).toFixed(1) : '0'}%`, 'chart', `${number(s.admissions)} confirmed admissions`]
  ];
  return `<div class="metric-grid">${cards.map(([label, value, glyph, note]) => `<section class="metric-card"><div class="metric-head">${label}<span class="metric-icon">${icon(glyph)}</span></div><div class="metric-value">${value}</div><div class="metric-note">${escape(note)}</div></section>`).join('')}</div>`;
}
async function dashboard(query, reports, token) {
  const data = await api(`/dashboard?${query}`);
  let recent;
  if (!reports && writer()) recent = await api('/leads?sort=recent');
  if (token !== navigation) return;
  const s = data.snapshot;
  let html = heading(reports ? 'INSIGHTS & ACTIVITY' : 'YOUR DAY, AT A GLANCE', reports ? 'Team performance' : 'Admissions overview',
    reports ? 'Understand activity, spot bottlenecks, and make every follow-up count.' : `Welcome back, ${user.username.split(' ')[0]}. Let’s turn conversations into possibilities.`,
    reports ? '' : createButton());
  if (!reports) html += `<section class="welcome-banner"><div><h2>A brighter future starts with a conversation.</h2><p>${s.due ? `${number(s.due)} follow-ups are ready for your attention.` : 'Your next meaningful connection is just a call away.'} Every student journey matters.</p></div>${writer() ? '<a href="#followups" class="banner-badge text-decoration-none">Open follow-up queue &nbsp; →</a>' : '<span class="banner-badge">Connect. Counsel. Inspire.</span>'}</section>`;
  if (reports) html += `<form class="date-range mb-4" data-form="report-filter"><label for="range-from" class="small">From</label><input id="range-from" class="form-control" type="date" name="from" value="${escape(data.from)}" required><label for="range-to" class="small">To</label><input id="range-to" class="form-control" type="date" name="to" value="${escape(data.to)}" required><button class="btn btn-primary" type="submit">Apply dates</button><span class="small text-muted">Activity dates in ${escape(data.timezone)}</span></form>`;
  html += metrics(data);
  const pipeline = statuses.map(status => {
    const count = data.pipeline.find(p => p.lead_status === status)?.count || 0;
    return `<div class="pipeline-row"><span class="progress-label">${escape(status.charAt(0) + status.slice(1).toLowerCase())}</span><progress class="w-100" max="${Math.max(s.total, 1)}" value="${count}" aria-label="${status} leads">${count}</progress><strong class="text-end">${number(count)}</strong></div>`;
  }).join('');
  const summary = user.role === 'OnField' ? [['Interested students', number(s.interested)], ['Parents convinced', number(s.parent_convinced)], ['Admissions confirmed', number(s.admissions)]]
    : [['Hot leads', number(s.hot)], ['Quoted fee value', money(s.quoted_value)], ['Admissions confirmed', number(s.admissions)], ['Average time to admission', data.average_conversion_days === null ? 'Not yet available' : `${data.average_conversion_days} days`]];
  html += `<div class="dashboard-middle">${panel('Lead pipeline', 'Current portfolio · confirmed admissions excluded', `<div class="panel-body">${pipeline}</div>`, '<span class="status status-WARM">LIVE SNAPSHOT</span>')}${panel('The bigger picture', 'Current portfolio, across all dates', `<div class="panel-body">${summary.map(([key, val]) => `<div class="summary-line"><span>${key}</span><strong>${val}</strong></div>`).join('')}</div>`)}</div>`;
  if (recent) html += panel('Recent leads', 'The newest student enquiries in your portfolio', leadTable(recent.items.slice(0, 6)), '<a class="btn btn-sm btn-link" href="#leads">View all leads →</a>');
  if (reports || !writer()) {
    html += panel('Conversion checklist coverage', 'Independent milestones, not a sequential funnel · current portfolio',
      `<div class="panel-body">${[['Interested', s.interested], ['Parent convinced', s.parent_convinced], ['Fee discussed', s.fee_discussed], ['Hostel explained', s.hostel_explained], ['Admission confirmed', s.admissions]].map(([label, count]) => `<div class="pipeline-row"><span>${label}</span><progress class="w-100" max="${Math.max(s.total, 1)}" value="${count}" aria-label="${label}">${count}</progress><strong class="text-end">${number(count)}</strong></div>`).join('')}</div>`);
    html += panel('Employee activity', `Calls and completed visits: ${data.from} to ${data.to} · admissions are current assigned totals`,
      `<div class="table-responsive"><table class="table"><thead><tr><th>Team member</th><th>Role</th><th>Calls made</th><th>Visits completed</th><th>Current admissions</th><th>Period confirmations</th></tr></thead><tbody>${data.employees.map(e => `<tr><td class="student-name">${escape(e.username)}</td><td>${escape(e.role)}</td><td>${number(e.calls)}</td><td>${number(e.visits)}</td><td>${number(e.admissions)}</td><td>${number(e.confirmations)}</td></tr>`).join('')}</tbody></table></div>`);
    if (data.daily.length) html += panel('Daily activity', 'Logged call attempts and distinct students confirmed each day (not net admissions)',
      `<div class="table-responsive"><table class="table"><thead><tr><th>Date</th><th>Call attempts</th><th>Admission confirmations</th></tr></thead><tbody>${data.daily.map(d => `<tr><td>${escape(d.day)}</td><td>${number(d.calls)}</td><td>${number(d.confirmations)}</td></tr>`).join('')}</tbody></table></div>`);
  }
  $('#main').innerHTML = html;
}
async function leadsPage(query, followups, token) {
  if (!writer()) throw new Error('Your role does not have access to individual lead records.');
  if (followups && !query.has('queue')) query.set('queue', 'due');
  const data = await api(`/leads?${query}`);
  if (token !== navigation) return;
  const route = followups ? 'followups' : 'leads';
  $('#main').innerHTML = heading(followups ? 'MAKE EVERY CONVERSATION COUNT' : 'STUDENT RELATIONSHIPS', followups ? 'Your follow-up queue' : 'Lead directory',
    followups ? `Ordered strictly by scheduled date and time · ${settings.timezone}. Lost and admitted leads are excluded.` : 'One place for student details, conversations, and the next step.', createButton()) +
    `<section class="panel"><form class="toolbar" data-form="lead-filter" data-route="${route}"><input class="form-control" name="search" aria-label="Search leads" placeholder="Search student, parent, or phone..." value="${escape(query.get('search') || '')}"><select class="form-select" name="status" aria-label="Lead status">${[['', 'All statuses'], ...statuses.map(s => [s, s])].map(([v, l]) => `<option value="${v}" ${query.get('status') === v ? 'selected' : ''}>${l}</option>`).join('')}</select><select class="form-select" name="queue" aria-label="Schedule filter">${[['all', 'All schedules'], ['due', 'Due now & overdue'], ['upcoming', 'Upcoming'], ['unscheduled', 'Unscheduled']].map(([v, l]) => `<option value="${v}" ${(query.get('queue') || 'all') === v ? 'selected' : ''}>${l}</option>`).join('')}</select><button class="btn btn-primary" type="submit">Apply filters</button></form>${leadTable(data.items)}${pagination(data, route, query)}</section>`;
}
const profileSections = [
  ['Student & family', [
    ['student_name', 'Student name', 'text', true], ['gender', 'Gender', 'select', false, [['', 'Not specified'], ['M', 'Male'], ['F', 'Female'], ['O', 'Other']]],
    ['parent_name', 'Parent / guardian name'], ['relation', 'Relationship', 'select', false, ['', 'Father', 'Mother', 'Guardian']],
    ['student_mobile', 'Student mobile', 'tel'], ['parent_mobile', 'Parent mobile', 'tel'], ['location', 'Area / location'], ['address', 'Home address', 'textarea']
  ]],
  ['Academic requirements', [
    ['current_school', 'Current school'], ['class', 'Current class'], ['board', 'Education board'], ['academic_year', 'Academic year', 'text', false],
    ['target_course', 'Target course'], ['goal', 'Student goal'], ['academic_level', 'Academic level'], ['expected_score', 'Expected score']
  ]],
  ['Source & counselling', [
    ['source', 'Lead source', 'select', false, ['', 'Walk-in', 'Phone enquiry', 'School outreach', 'Referral', 'Website', 'Campaign']],
    ['lead_type', 'Lead type'], ['preferred_campus', 'Preferred campus'], ['program_discussed', 'Program discussed']
  ]],
  ['Fee discussion', [
    ['quoted_fee', 'Quoted fee (INR)', 'number'], ['expected_budget', 'Expected budget (INR)', 'number'],
    ['scholarship_status', 'Scholarship status'], ['parent_objections', 'Parent concerns / objections', 'textarea']
  ]],
  ['Status & next steps', [
    ['lead_status', 'Lead status', 'select', true, statuses], ['campus_visit', 'Campus visit', 'select', false, ['', 'Not planned', 'Planned', 'Completed']],
    ['next_followup_date', 'Next follow-up date', 'date'], ['next_followup_time', 'Next follow-up time', 'time'],
    ['expected_admission_date', 'Expected admission date', 'date']
  ]]
];
const flags = [['whatsapp_opt_in', 'Family opted in to WhatsApp communication'], ['counselling_appointment', 'Counselling appointment requested'],
  ['is_interested', 'Student is interested'], ['is_parent_convinced', 'Parent is convinced'], ['is_fee_discussed', 'Fee has been discussed'],
  ['is_hostel_explained', 'Hostel has been explained'], ['is_admission_confirmed', 'Admission is confirmed']];
const assigneeOptions = role => [['', 'Unassigned'], ...assignees.filter(a => a.role === role).map(a => [a.user_id, a.username])];
function timeline(lead) {
  if (!lead.timeline?.length) return empty('The journey starts here', 'Save this lead to begin a record of every conversation.');
  return `<div class="panel-body"><ol class="timeline">${lead.timeline.map(e => `<li class="timeline-item"><div class="timeline-title">${escape(e.event_type)}</div><div class="timeline-date">${escape(timestamp(e.created_at))} · ${escape(e.username)}</div><div class="timeline-detail">${escape(e.detail.outcome || e.detail.status || '')}${e.detail.notes || e.detail.report ? `<br>${escape(e.detail.notes || e.detail.report)}` : ''}${e.detail.followup ? `<br>Follow-up: ${escape(e.detail.followup)}` : ''}${e.detail.fields?.length ? `<br>Updated: ${escape(e.detail.fields.map(f => f.replaceAll('_', ' ')).join(', '))}` : ''}</div></li>`).join('')}</ol></div>`;
}
async function leadPage(id, token) {
  if (!writer()) throw new Error('Your role does not have access to this workspace.');
  const fresh = id === 'new';
  const [lead, available] = await Promise.all([fresh ? Promise.resolve({ lead_status: 'PENDING', academic_year: `${new Date().getFullYear()}-${new Date().getFullYear() + 1}` }) : api(`/leads/${id}`), api('/assignees')]);
  if (token !== navigation) return;
  currentLead = lead; assignees = available;
  const sections = profileSections.map(([title, inputs], index) => `<section class="form-section"><div class="section-title"><span class="section-number">0${index + 1}</span><h2>${title}</h2></div><div class="row g-3">${inputs.map(([name, label, type, required, options]) => field(name, label, lead[name], type, required, options)).join('')}</div>${index === 4 ? `<p class="form-text mt-3 mb-0">Enter both follow-up date and time. All schedules use ${escape(settings.timezone)}.</p>` : ''}</section>`).join('');
  $('#main').innerHTML = heading(fresh ? 'START A NEW CONVERSATION' : 'STUDENT PROFILE', fresh ? 'New admission lead' : lead.student_name,
    fresh ? 'Capture the essentials today. Build the relationship with every follow-up.' : `${lead.parent_name || 'Parent not provided'} · ${lead.location || 'Location not provided'} · ${lead.callno} logged calls`,
    `<a class="btn btn-outline-secondary" href="#leads">Back to leads</a>${!fresh ? `<button class="btn btn-primary" data-action="call">${icon('phone')} Log a call</button>` : ''}`) +
    `<div class="lead-layout"><form class="panel" data-form="lead">${fresh && operator() ? `<section class="form-section"><div class="row g-3">${field('assigned_to', 'Assigned telecaller', '', 'select', false, assigneeOptions('Staff'))}</div></section>` : ''}${sections}<section class="form-section"><div class="section-title"><span class="section-number">06</span><h2>Conversion checklist</h2></div><div class="checklist">${flags.map(([key, label]) => check(key, label, lead[key])).join('')}</div></section><div class="form-error mx-4" role="alert"></div><div class="sticky-actions"><button class="btn btn-primary" type="submit">${icon('check')} ${fresh ? 'Create lead' : 'Save profile'}</button></div></form><aside>${!fresh ? panel('Caller control', 'Every call counts. Log the outcome after dialing.',
      `<div class="panel-body"><div class="d-flex gap-2 flex-wrap mb-3">${badge(lead)}<span class="status status-PENDING">${number(lead.callno)} CALLS</span></div><div class="summary-line"><span>Parent / guardian</span>${telephone(lead.parent_mobile)}</div><div class="summary-line"><span>Student</span>${telephone(lead.student_mobile)}</div><div class="summary-line"><span>Next follow-up</span><strong>${escape(followup(lead))}</strong></div><button class="btn btn-outline-secondary w-100 mt-3" data-action="request-visit">${icon('pin')} Request home visit</button>${operator() ? '<button class="btn btn-outline-secondary w-100 mt-2" data-action="assign">Reassign lead</button>' : ''}${user.role === 'SuperAdmin' ? '<button class="btn btn-link text-danger mt-2" data-action="delete-lead">Delete lead and history</button>' : ''}</div>`) : '<div class="hint-card mb-4">Start with a student name and a contact number. A scheduled next step keeps every family in the conversation.</div>'}
      ${user.role === 'SuperAdmin' && lead.calls?.length ? panel('Call records', 'SuperAdmin corrections retain a journey audit trail', `<div class="panel-body">${lead.calls.map(c => `<div class="mb-3"><strong class="small">${escape(c.call_outcome)}</strong><div class="student-sub">${escape(timestamp(c.call_timestamp))} · ${escape(c.username)}</div><div class="small pre-wrap mt-2">${escape(c.followup_notes)}</div><button class="btn btn-sm btn-link ps-0" data-action="correct-call" data-id="${c.log_id}">Correct</button><button class="btn btn-sm btn-link text-danger" data-action="delete-call" data-id="${c.log_id}">Delete</button></div>`).join('')}</div>`) : ''}
      ${panel('Lead journey', 'A shared history, one conversation at a time', timeline(lead))}
      ${lead.visits?.length ? panel('Home visits', 'Field feedback returns directly to this profile', `<div class="panel-body">${lead.visits.map(v => `<div class="mb-3"><strong class="small">${escape(v.username)}</strong><span class="status status-WARM ms-2">${escape(v.status)}</span><div class="small text-muted mt-2 pre-wrap">${escape(v.visit_report || v.request_notes)}</div>${v.entry_date ? `<div class="student-sub">Visited ${escape(v.entry_date)} · ${escape(v.contact_verified)}</div>` : ''}</div>`).join('')}</div>`) : ''}</aside></div>`;
}
function callDialog() {
  modal('Log a call attempt', `<form data-form="call"><div class="field-help">Record the actual outcome, including unanswered calls. This adds one call to the student’s history.</div><div class="row g-3">${field('call_outcome', 'Call outcome', 'Answered', 'select', true, ['Answered', 'Unanswered', 'Invalid Number', 'Requested Callback', 'Not Interested'])}${field('lead_status', 'Lead status', currentLead.lead_status, 'select', true, statuses)}${field('next_followup_date', 'Next follow-up date', currentLead.next_followup_date, 'date')}${field('next_followup_time', 'Next follow-up time', currentLead.next_followup_time, 'time')}${field('followup_notes', 'Conversation notes', '', 'textarea', true)}</div><p class="form-text">Schedules use ${escape(settings.timezone)}. Requested callbacks require a date and time.</p>${formEnd('Save call attempt')}`);
}
async function visitsPage(query, token) {
  const data = await api(`/visits?${query}`);
  if (operator()) assignees = await api('/assignees');
  if (token !== navigation) return;
  currentVisits = data.items;
  $('#main').innerHTML = heading('OUTREACH, WITH A PERSONAL TOUCH', 'Field visits', 'Meet families where they are. Bring the conversation back to the team.') +
    `<div class="tabs-row mb-4"><a class="btn ${query.get('status') !== 'COMPLETED' ? 'btn-primary' : 'btn-outline-secondary'}" href="#visits?status=REQUESTED">Pending visits</a><a class="btn ${query.get('status') === 'COMPLETED' ? 'btn-primary' : 'btn-outline-secondary'}" href="#visits?status=COMPLETED">Completed visits</a></div>` +
    (data.items.length ? `<div class="visit-grid">${data.items.map(v => `<article class="visit-card"><div class="d-flex justify-content-between gap-2"><div><h2>${escape(v.student_name)}</h2><div class="student-sub">${escape(v.parent_name)} · ${escape(v.target_course || 'Course not specified')}</div></div><span class="status status-${v.status === 'COMPLETED' ? 'WARM' : 'PENDING'}">${v.status === 'COMPLETED' ? 'COMPLETED' : 'TO VISIT'}</span></div><div class="visit-address">${icon('pin')} ${escape(v.address || 'Address not yet provided')}<br>${escape(v.location)}</div><div class="d-flex gap-3 mb-3">${telephone(v.parent_mobile || v.student_mobile)}</div><div class="visit-notes">${escape(v.visit_report || v.request_notes)}</div>${v.parent_objections ? `<p class="small text-muted mt-3 pre-wrap">Parent concerns: ${escape(v.parent_objections)}</p>` : ''}<div class="student-sub mt-3">Assigned to ${escape(v.username)} · Requested ${escape(timestamp(v.requested_at))}</div>${v.status === 'REQUESTED' ? `<div class="d-flex gap-2 mt-3"><button class="btn btn-primary flex-grow-1" data-action="complete-visit" data-id="${v.visit_id}">${icon('check')} Submit visit report</button>${operator() ? `<button class="btn btn-outline-secondary" data-action="assign-visit" data-id="${v.visit_id}">Reassign</button>` : ''}</div>` : `<p class="small text-muted mt-3 mb-0">Visited ${escape(v.entry_date)} · ${escape(v.contact_verified)}${v.latitude !== null ? ' · GPS captured' : ''}</p>`}${user.role === 'SuperAdmin' ? `<div class="d-flex gap-2 mt-3">${v.status === 'COMPLETED' ? `<button class="btn btn-sm btn-outline-secondary" data-action="correct-visit" data-id="${v.visit_id}">Correct report</button>` : ''}<button class="btn btn-sm btn-link text-danger" data-action="delete-visit" data-id="${v.visit_id}">Delete visit</button></div>` : ''}</article>`).join('')}</div>` : `<section class="panel">${empty('No visits in this queue', 'Home visits requested by the admissions team will appear here.', 'pin')}</section>`) + pagination(data, 'visits', query);
}
function visitDialog(id) {
  const v = currentVisits.find(item => item.visit_id === id);
  if (!v) throw new Error('Reload the visit queue and try again.');
  modal(`Visit report · ${v.student_name}`, `<form data-form="complete-visit" data-id="${id}"><div class="field-help">Assigned employee: ${escape(v.username)}. Include parent objections, interest levels, and the agreed next step.</div><div class="row g-3">${field('entry_date', 'Visit date', today(), 'date', true)}${field('area', 'Area', v.location, 'text', true)}${field('address_visited', 'Address visited', v.address, 'textarea', true)}${field('contact_verified', 'Contact verification', 'Verified', 'select', true, ['Verified', 'Not available', 'Incorrect address'])}${field('visit_report', 'Visiting report (at least 10 characters)', '', 'textarea', true)}</div><div class="mt-3"><button type="button" class="btn btn-outline-secondary" data-action="gps">${icon('pin')} Capture my location (optional)</button><div id="gps-status" class="form-text" role="status">Only captured with your permission. Location is not a guarantee of visit proximity.</div><input type="hidden" name="latitude"><input type="hidden" name="longitude"></div>${formEnd('Complete visit')}`);
}
async function usersPage(token) {
  const data = await api('/users');
  if (token !== navigation) return;
  currentUsers = data;
  $('#main').innerHTML = heading('A TEAM THAT MAKES A DIFFERENCE', 'Team members', operator() && user.role === 'Admin' ? 'Manage telecallers and field representatives.' : 'Manage accounts and access across your college.',
    `<button class="btn btn-primary" data-action="new-user">${icon('plus')} Add team member</button>`) +
    panel('People & access', 'Reassign outstanding work before deactivating an account.', `<div class="table-responsive"><table class="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Access</th><th>Actions</th></tr></thead><tbody>${data.map(u => `<tr><td class="student-name">${escape(u.username)}</td><td>${escape(u.email)}</td><td>${escape(u.role)}</td><td><span class="status status-${u.is_active ? 'WARM' : 'LOST'}">${u.is_active ? 'Active' : 'Inactive'}</span></td><td><button class="btn btn-sm btn-outline-secondary" data-action="edit-user" data-id="${u.user_id}">Edit account</button>${user.role === 'SuperAdmin' && u.user_id !== user.user_id ? `<button class="btn btn-sm btn-link text-danger" data-action="delete-user" data-id="${u.user_id}">Delete</button>` : ''}</td></tr>`).join('')}</tbody></table></div>`);
}
function userDialog(id) {
  const u = currentUsers.find(a => a.user_id === id) || { role: 'Staff', is_active: true };
  modal(id ? 'Edit team member' : 'Add team member', `<form data-form="user" data-id="${id || ''}"><div class="row g-3">${field('username', 'Name / username', u.username, 'text', true)}${field('email', 'Work email', u.email, 'email', true)}${field('role', 'Role', u.role, 'select', true, user.role === 'SuperAdmin' ? ['SuperAdmin', 'Admin', 'Management', 'Staff', 'OnField'] : ['Staff', 'OnField'])}${field('password', id ? 'New password (leave empty to keep)' : 'Initial password', '', 'password', !id)}</div><div class="form-text mt-3">Passwords require at least 12 characters. Account updates sign the user out of existing sessions.</div><div class="mt-3">${check('is_active', 'Account is active', u.is_active)}</div>${formEnd(id ? 'Save account' : 'Create account')}`);
}
function dataPage() {
  if (!operator()) throw new Error('Import and export are available to administrators only.');
  $('#main').innerHTML = heading('KEEP YOUR PIPELINE ORGANIZED', 'Import & export', 'Bring new enquiries into one shared, structured workspace.') +
    `<div class="dashboard-middle">${panel('Import new leads', 'UTF-8 CSV · up to 2,000 records · maximum 2 MB',
      `<div class="panel-body"><p class="small text-muted">Start with the template below. Imports are atomic: if any row is invalid, no leads are created. This creates new leads, not updates.</p><button class="btn btn-outline-secondary mb-4" data-action="template">${icon('download')} Download CSV template</button><form data-form="import"><label for="csv-file" class="form-label">Choose CSV file</label><input id="csv-file" class="form-control" name="file" type="file" accept=".csv,text/csv" required><div class="form-text">Use active Staff UUIDs in assigned_to. Omit it to create unassigned leads. Date: YYYY-MM-DD; time: HH:mm; booleans: true/false.</div><div class="form-error mt-3" role="alert"></div><button class="btn btn-primary mt-3" type="submit">Validate & import</button></form></div>`)}
    ${panel('Export lead directory', 'Administrator-only download · maximum 10,000 records', `<div class="panel-body"><p class="small text-muted">Download a snapshot of all lead profiles. Call and visit histories remain in the application. Exports are audited and formula-prefixed cells are neutralized.</p><button class="btn btn-outline-secondary" data-action="export">${icon('download')} Export leads</button><div class="hint-card mt-4">Student and parent contact data is confidential. Share exports only with authorized colleagues and delete them when no longer required.</div></div>`)}</div>`;
}
async function settingsPage(token) {
  const audit = await api('/audit');
  if (token !== navigation) return;
  $('#main').innerHTML = heading('WORKSPACE ADMINISTRATION', 'Settings & audit', 'Manage global settings and review administrative activity.') +
    panel('College configuration', 'Timezone changes affect scheduling and reporting across the team.',
      `<form class="panel-body" data-form="settings"><div class="row g-3">${field('college_name', 'College name', settings.college_name, 'text', true)}${field('timezone', 'IANA timezone', settings.timezone, 'text', true)}</div><div class="form-text">For example: Asia/Kolkata. Existing follow-ups retain their local date and time.</div><div class="form-error mt-3" role="alert"></div><button class="btn btn-primary mt-3" type="submit">Save settings</button></form>`) +
    panel('Administrative audit', 'Most recent 200 actions · immutable through the application', `<div class="table-responsive"><table class="table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Target</th></tr></thead><tbody>${audit.map(a => `<tr><td>${escape(timestamp(a.created_at))}</td><td>${escape(a.username || 'Deleted account')}</td><td>${escape(a.action)}</td><td>${escape(a.target)}</td></tr>`).join('')}</tbody></table></div>`);
}
async function route() {
  if (!user) return;
  const token = ++navigation;
  const [path = 'dashboard', search = ''] = location.hash.slice(1).split('?');
  const [page, id] = (path || 'dashboard').split('/');
  const query = new URLSearchParams(search);
  $('.sidebar')?.classList.remove('open');
  $('[data-action="menu"]')?.setAttribute('aria-expanded', 'false');
  document.querySelectorAll('[data-nav]').forEach(el => {
    const active = el.dataset.nav === (page === 'lead' ? 'leads' : page);
    el.classList.toggle('active', active);
    if (active) el.setAttribute('aria-current', 'page'); else el.removeAttribute('aria-current');
  });
  $('#main').innerHTML = '<div class="empty-state" role="status">Loading your workspace...</div>';
  try {
    if (page === 'dashboard' || page === 'reports') {
      if (page === 'reports' && !operator() && user.role !== 'Management') throw new Error('Team performance is available to management and administrators.');
      await dashboard(query, page === 'reports', token);
    } else if (page === 'leads' || page === 'followups') await leadsPage(query, page === 'followups', token);
    else if (page === 'lead' && id) await leadPage(id, token);
    else if (page === 'visits') await visitsPage(query, token);
    else if (page === 'users') await usersPage(token);
    else if (page === 'data') dataPage();
    else if (page === 'settings') await settingsPage(token);
    else throw new Error('This workspace page was not found.');
    if (token === navigation) {
      document.title = `${$('#main h1')?.textContent || 'Workspace'} | Shastra`;
      $('#main').focus({ preventScroll: true });
    }
  } catch (error) {
    if (token === navigation && user) $('#main').innerHTML = `<div class="error-panel" role="alert"><h2 class="mb-2">We couldn’t open this view</h2><p>${escape(error.message)}</p><button class="btn btn-outline-secondary" data-action="reload">Try again</button></div>`;
  }
}
function formData(form) { return Object.fromEntries(new FormData(form)); }
async function saved(message) { hideModal(); notify(message); await route(); }
const formActions = {
  async login(form) {
    const session = await api('/auth/me'); csrf = session.csrf;
    const result = await api('/auth/login', { method: 'POST', body: formData(form) });
    user = result.user; csrf = result.csrf; settings = await api('/settings'); shell();
    if (location.hash !== '#dashboard') location.hash = 'dashboard'; else await route();
  },
  async lead(form) {
    const data = formData(form);
    for (const [name] of flags) data[name] = form.elements[name].checked;
    for (const name of ['quoted_fee', 'expected_budget']) data[name] = data[name] === '' ? null : Number(data[name]);
    for (const name of ['next_followup_date', 'next_followup_time', 'expected_admission_date']) data[name] = data[name] || null;
    if ('assigned_to' in data) data.assigned_to ||= null;
    const fresh = !currentLead.lead_id;
    if (!fresh) data.version = currentLead.version;
    const result = await api(fresh ? '/leads' : `/leads/${currentLead.lead_id}`, { method: fresh ? 'POST' : 'PUT', body: data });
    notify(fresh ? 'Lead created. A new student journey begins.' : 'Student profile saved.');
    if (fresh) location.hash = `lead/${result.lead_id}`; else await route();
  },
  async call(form) {
    const data = formData(form);
    data.next_followup_date ||= null; data.next_followup_time ||= null; data.version = currentLead.version;
    await api(`/leads/${currentLead.lead_id}/calls`, { method: 'POST', body: data });
    await saved('Call attempt logged and follow-up updated.');
  },
  async 'request-visit'(form) {
    await api(`/leads/${currentLead.lead_id}/visits`, { method: 'POST', body: formData(form) });
    await saved('Home visit assigned to the field team.');
  },
  async assignment(form) {
    await api(`/leads/${currentLead.lead_id}/assignment`, { method: 'PUT', body: { assigned_to: formData(form).assigned_to || null, version: currentLead.version } });
    await saved('Lead reassigned.');
  },
  async 'assign-visit'(form) {
    await api(`/visits/${form.dataset.id}/assignment`, { method: 'PUT', body: formData(form) });
    await saved('Field visit reassigned.');
  },
  async 'complete-visit'(form) {
    const data = formData(form);
    data.latitude = data.latitude === '' ? null : Number(data.latitude);
    data.longitude = data.longitude === '' ? null : Number(data.longitude);
    await api(`/visits/${form.dataset.id}/complete`, { method: 'PUT', body: data });
    await saved('Visit report submitted. Thank you for connecting with the family.');
  },
  async user(form) {
    const data = formData(form); data.is_active = form.elements.is_active.checked;
    if (!data.password) delete data.password;
    const id = form.dataset.id;
    await api(id ? `/users/${id}` : '/users', { method: id ? 'PUT' : 'POST', body: data });
    await saved(id ? 'Account updated.' : 'Team member created.');
  },
  async settings(form) {
    settings = await api('/settings', { method: 'PUT', body: formData(form) });
    shell(); notify('Workspace settings updated.'); await route();
  },
  async password(form) {
    await api('/auth/password', { method: 'POST', body: formData(form) });
    hideModal(); notify('Password changed. Other sessions have been signed out.');
  },
  async import(form) {
    const file = form.elements.file.files[0];
    if (!file || file.size > 2 * 1024 * 1024) throw new Error('Select a CSV file no larger than 2 MB.');
    const result = await api('/leads/import', { method: 'POST', headers: { 'Content-Type': 'text/csv' }, body: await file.text() });
    notify(`${result.imported} leads imported successfully.`); form.reset();
  },
  async 'lead-filter'(form) { location.hash = `${form.dataset.route}?${new URLSearchParams(formData(form))}`; },
  async 'report-filter'(form) { location.hash = `reports?${new URLSearchParams(formData(form))}`; },
  async 'delete-lead'() {
    await api(`/leads/${currentLead.lead_id}`, { method: 'DELETE', body: { version: currentLead.version } });
    hideModal(); notify('Lead and its history deleted.'); location.hash = 'leads';
  },
  async 'delete-user'(form) {
    await api(`/users/${form.dataset.id}`, { method: 'DELETE' }); await saved('Account deleted.');
  },
  async 'correct-call'(form) {
    await api(`/calls/${form.dataset.id}`, { method: 'PUT', body: formData(form) });
    await saved('Call record corrected. Original timeline entries remain for accountability.');
  },
  async 'delete-call'(form) {
    await api(`/calls/${form.dataset.id}`, { method: 'DELETE', body: formData(form) });
    await saved('Call record deleted and the call count updated.');
  },
  async 'correct-visit'(form) {
    const data = formData(form);
    data.latitude = data.latitude === '' ? null : Number(data.latitude);
    data.longitude = data.longitude === '' ? null : Number(data.longitude);
    await api(`/visits/${form.dataset.id}`, { method: 'PUT', body: data });
    await saved('Visit report corrected with an audit record.');
  },
  async 'delete-visit'(form) {
    await api(`/visits/${form.dataset.id}`, { method: 'DELETE', body: formData(form) });
    await saved('Visit record deleted with an audit record.');
  }
};
document.addEventListener('submit', async event => {
  const form = event.target.closest('form[data-form]');
  if (!form) return;
  event.preventDefault();
  const submit = $('[type="submit"]', form), errorBox = $('.form-error', form);
  if (submit?.disabled) return;
  if (submit) submit.disabled = true;
  if (errorBox) errorBox.innerHTML = '';
  try { await formActions[form.dataset.form](form); }
  catch (error) {
    if (errorBox && document.contains(form)) errorBox.innerHTML = `<div class="alert alert-danger mb-0">${escape(error.message)}</div>`;
    else notify(error.message, 'danger');
  } finally { if (submit) submit.disabled = false; }
});
function download(blob, filename) {
  const url = URL.createObjectURL(blob), link = document.createElement('a');
  link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 5000);
}
const actions = {
  menu() { const open = $('.sidebar').classList.toggle('open'); $('[data-action="menu"]').setAttribute('aria-expanded', String(open)); },
  async logout() { await api('/auth/logout', { method: 'POST' }); user = null; navigation++; hideModal(); loginScreen(); },
  reload: route,
  call: callDialog,
  'request-visit'() {
    modal('Request a home visit', `<form data-form="request-visit"><div class="row g-3">${field('field_employee_id', 'Field representative', '', 'select', true, assigneeOptions('OnField').map(([id, label]) => [id, id ? label : 'Select a representative']))}${field('request_notes', 'Visit briefing', '', 'textarea', true)}</div>${formEnd('Request visit')}`);
  },
  assign() {
    modal('Reassign lead', `<form data-form="assignment"><div class="row g-3">${field('assigned_to', 'Assigned telecaller', currentLead.assigned_to, 'select', false, assigneeOptions('Staff'))}</div><p class="form-text mt-3">The previous telecaller will lose access immediately.</p>${formEnd('Reassign lead')}`);
  },
  'complete-visit': button => visitDialog(button.dataset.id),
  'assign-visit'(button) {
    const visit = currentVisits.find(v => v.visit_id === button.dataset.id);
    modal('Reassign field visit', `<form data-form="assign-visit" data-id="${visit.visit_id}"><div class="row g-3">${field('field_employee_id', 'Field representative', visit.field_employee_id, 'select', true, assigneeOptions('OnField'))}</div>${formEnd('Reassign visit')}`);
  },
  gps(button) {
    if (!navigator.geolocation) throw new Error('This browser does not support location capture. You can submit without GPS.');
    button.disabled = true;
    const form = button.closest('form'), status = $('#gps-status');
    status.textContent = 'Waiting for your location permission...';
    navigator.geolocation.getCurrentPosition(position => {
      form.elements.latitude.value = position.coords.latitude;
      form.elements.longitude.value = position.coords.longitude;
      status.textContent = `Location captured · accuracy approximately ${Math.round(position.coords.accuracy)} metres.`;
      button.disabled = false;
    }, error => {
      status.textContent = `Location not captured: ${error.message}. You can still submit the visit report.`;
      button.disabled = false;
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  },
  'new-user': () => userDialog(),
  'edit-user': button => userDialog(button.dataset.id),
  password() {
    modal('Change your password', `<form data-form="password"><div class="row g-3">${field('current_password', 'Current password', '', 'password', true)}${field('new_password', 'New password', '', 'password', true)}</div><p class="form-text mt-3">Use at least 12 characters. Other sessions will be signed out.</p>${formEnd('Change password')}`);
  },
  'delete-lead'() {
    modal('Permanently delete this lead?', `<form data-form="delete-lead"><div class="alert alert-danger">This deletes ${escape(currentLead.student_name)} and all their calls, visits, and journey events. This cannot be undone. The deletion itself will remain in the administrative audit.</div>${formEnd('Permanently delete lead')}`);
  },
  'delete-user'(button) {
    modal('Permanently delete this account?', `<form data-form="delete-user" data-id="${button.dataset.id}"><p>Accounts referenced by student or activity history cannot be deleted. Deactivate them instead to retain accountability.</p>${formEnd('Delete account')}`);
  },
  'correct-call'(button) {
    const call = currentLead.calls.find(c => c.log_id === button.dataset.id);
    modal('Correct call record', `<form data-form="correct-call" data-id="${call.log_id}"><div class="field-help">Correcting a historical call does not change the current lead status or follow-up schedule.</div><div class="row g-3">${field('call_outcome', 'Call outcome', call.call_outcome, 'select', true, ['Answered', 'Unanswered', 'Invalid Number', 'Requested Callback', 'Not Interested'])}${field('followup_notes', 'Call notes', call.followup_notes, 'textarea', true)}${field('correction_reason', 'Reason for correction', '', 'textarea', true)}</div>${formEnd('Correct call record')}`);
  },
  'delete-call'(button) {
    modal('Delete call record?', `<form data-form="delete-call" data-id="${button.dataset.id}"><p>This removes the attempt from call counts. Original journey events are retained, with an additional deletion event.</p><div class="row g-3">${field('correction_reason', 'Reason for deletion', '', 'textarea', true)}</div>${formEnd('Delete call record')}`);
  },
  'correct-visit'(button) {
    const v = currentVisits.find(v => v.visit_id === button.dataset.id);
    modal('Correct visit report', `<form data-form="correct-visit" data-id="${v.visit_id}"><div class="row g-3">${field('entry_date', 'Visit date', v.entry_date, 'date', true)}${field('area', 'Area', v.area, 'text', true)}${field('address_visited', 'Address visited', v.address_visited, 'textarea', true)}${field('contact_verified', 'Contact verification', v.contact_verified, 'select', true, ['Verified', 'Not available', 'Incorrect address'])}${field('visit_report', 'Visit report', v.visit_report, 'textarea', true)}${field('correction_reason', 'Reason for correction', '', 'textarea', true)}</div><input type="hidden" name="latitude" value="${escape(v.latitude)}"><input type="hidden" name="longitude" value="${escape(v.longitude)}">${formEnd('Correct visit report')}`);
  },
  'delete-visit'(button) {
    modal('Delete field visit?', `<form data-form="delete-visit" data-id="${button.dataset.id}"><p>This permanently removes the visit record. A deletion event remains on the student journey.</p><div class="row g-3">${field('correction_reason', 'Reason for deletion', '', 'textarea', true)}</div>${formEnd('Delete visit')}`);
  },
  template() {
    download(new Blob(['student_name,parent_name,parent_mobile,location,address,current_school,class,board,academic_year,target_course,source,lead_status,next_followup_date,next_followup_time,assigned_to\r\n'], { type: 'text/csv' }), 'shastra-import-template.csv');
  },
  async export() {
    const response = await fetch('/api/leads/export');
    if (!response.ok) throw new Error((await response.json()).error || 'Export failed.');
    download(await response.blob(), 'shastra-leads.csv'); notify('Lead export downloaded. Keep student data confidential.');
  }
};
document.addEventListener('click', async event => {
  const button = event.target.closest('[data-action]');
  if (!button || button.disabled) return;
  try { await actions[button.dataset.action](button); }
  catch (error) { notify(error.message, 'danger'); }
});
window.addEventListener('hashchange', route);
try {
  const session = await api('/auth/me'); csrf = session.csrf; user = session.user;
  if (user) { settings = await api('/settings'); shell(); await route(); } else loginScreen();
} catch (error) {
  $('#app').innerHTML = `<main id="main"><div class="error-panel" role="alert"><h1>Unable to connect</h1><p>${escape(error.message)}</p><p>Check that the application and database are running, then reload this page.</p></div></main>`;
}

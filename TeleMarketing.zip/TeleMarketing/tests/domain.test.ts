import { test } from 'node:test';
import assert from 'node:assert/strict';
import { canManageRole, csvCell, leadInput, callInput, password, roles } from '../src/domain.js';

test('every role obeys the account-management matrix', () => {
  for (const role of roles) {
    for (const target of roles) {
      assert.equal(canManageRole(role, target),
        role === 'SuperAdmin' || (role === 'Admin' && ['Staff', 'OnField'].includes(target)));
    }
  }
});
test('minimal lead defaults preserve the complete required schema', () => {
  const lead = leadInput.parse({ student_name: 'Test Student' });
  assert.equal(lead.lead_status, 'PENDING');
  assert.equal(lead.next_followup_date, null);
  assert.equal(lead.is_admission_confirmed, false);
  assert.equal(lead.quoted_fee, null);
  assert.equal(lead.address, '');
  assert.equal(Object.keys(lead).length, 36);
});
test('dates, paired scheduling, money and phone numbers are validated', () => {
  const invalid = [
    { next_followup_date: '2026-02-30', next_followup_time: '10:30' },
    { next_followup_date: '0000-01-01', next_followup_time: '10:30' },
    { next_followup_date: '2026-10-05' },
    { next_followup_time: '10:00' },
    { next_followup_date: '2026-10-05', next_followup_time: '25:00' },
    { quoted_fee: -1 }, { expected_budget: Infinity }, { student_mobile: 'javascript:alert(1)' },
    { assigned_to: 'untrusted-assignee' }, { is_admission_confirmed: 'true' }
  ];
  for (const input of invalid) assert.equal(leadInput.safeParse({ student_name: 'Test Student', ...input }).success, false);
  assert.equal(leadInput.safeParse({ student_name: 'Test Student', next_followup_date: '2028-02-29', next_followup_time: '23:59' }).success, true);
});
test('callback attempts require an actual scheduled follow-up', () => {
  const input = { call_outcome: 'Requested Callback', followup_notes: 'Call tomorrow', lead_status: 'CALLBACK', version: 1, next_followup_date: null, next_followup_time: null };
  assert.equal(callInput.safeParse(input).success, false);
  assert.equal(callInput.safeParse({ ...input, next_followup_date: '2026-10-06', next_followup_time: '10:00' }).success, true);
});
test('CSV exports escape delimiters and neutralize spreadsheet formulas', () => {
  assert.equal(csvCell('a,"b"'), '"a,""b"""');
  assert.equal(csvCell('=SUM(1,2)'), '"\'=SUM(1,2)"');
  assert.equal(csvCell(' \t@payload'), '"\' \t@payload"');
  assert.equal(csvCell('+919876543210'), '"\'+919876543210"');
  assert.equal(csvCell(null), '""');
});
test('passwords cannot exceed bcrypt byte limit', () => {
  assert.equal(password.safeParse('short').success, false);
  assert.equal(password.safeParse('A sufficiently long password').success, true);
  assert.equal(password.safeParse('😀'.repeat(20)).success, false);
});

import 'dotenv/config';
import { before, after, describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import request from 'supertest';
import { createPool } from '../src/db.js';
import { migrate } from '../src/migrate.js';
import { createApp } from '../src/app.js';
import { leadInput, type Role } from '../src/domain.js';

const connection = process.env.TEST_DATABASE_URL;
if (!connection) throw new Error('Set TEST_DATABASE_URL to a disposable PostgreSQL database. Run npm run test:unit for database-independent tests.');
if (connection === process.env.DATABASE_URL) throw new Error('TEST_DATABASE_URL must not be the application DATABASE_URL.');
const schema = `crm_test_${randomUUID().replaceAll('-', '')}`;
const adminPool = createPool(connection);
const url = new URL(connection);
url.searchParams.set('options', `-csearch_path=${schema}`);
const pool = createPool(url.toString());
const app = createApp(pool, { secret: 'integration-tests-only-secret-at-least-32-chars', secure: false, trustProxy: 0 });
const pass = 'Test-only password 2026!';
type Client = { agent: ReturnType<typeof request.agent>; csrf: string; id: string };
const clients: Record<string, Client> = {};
const write = (client: Client, method: 'post' | 'put' | 'delete', path: string, body: object = {}) =>
  client.agent[method](`/api${path}`).set('X-CSRF-Token', client.csrf).send(body);
async function login(email: string, id: string): Promise<Client> {
  const agent = request.agent(app);
  const me = await agent.get('/api/auth/me').expect(200);
  const result = await agent.post('/api/auth/login').set('X-CSRF-Token', me.body.csrf).send({ email, password: pass }).expect(200);
  return { agent, csrf: result.body.csrf, id };
}
async function newLead(client: Client, extra: object = {}) {
  const result = await write(client, 'post', '/leads', { student_name: 'Integration Student', ...extra }).expect(201);
  return result.body.lead_id as string;
}
before(async () => {
  await adminPool.query(`CREATE SCHEMA ${schema}`);
  await migrate(pool);
  await migrate(pool);
  const hash = await bcrypt.hash(pass, 12);
  for (const [name, role] of Object.entries({ super: 'SuperAdmin', admin: 'Admin', manager: 'Management', staff: 'Staff', other: 'Staff', field: 'OnField', otherfield: 'OnField' })) {
    const id = randomUUID(), email = `${name}@test.invalid`;
    await pool.query('INSERT INTO users(user_id,username,email,password_hash,role) VALUES($1,$2,$3,$4,$5)', [id, name, email, hash, role]);
    clients[name] = await login(email, id);
  }
});
after(async () => {
  await pool.end();
  await adminPool.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE`);
  await adminPool.end();
});

describe('authentication and role boundaries', () => {
  test('anonymous requests, missing CSRF and invalid credentials are rejected', async () => {
    await request(app).get('/api/leads').expect(401);
    await clients.staff.agent.post('/api/leads').send({ student_name: 'Blocked' }).expect(403);
    const anonymous = request.agent(app);
    const me = await anonymous.get('/api/auth/me');
    await anonymous.post('/api/auth/login').set('X-CSRF-Token', me.body.csrf).send({ email: 'unknown@test.invalid', password: pass }).expect(401);
    await clients.staff.agent.post('/api/leads').set('X-CSRF-Token', 'é'.repeat(64)).send({ student_name: 'Blocked' }).expect(403);
  });
  test('Staff cannot access another staff queue or change lead assignment', async () => {
    const id = await newLead(clients.staff);
    await clients.other.agent.get(`/api/leads/${id}`).expect(404);
    const list = await clients.other.agent.get('/api/leads').expect(200);
    assert.equal(list.body.items.some((l: { lead_id: string }) => l.lead_id === id), false);
    await write(clients.staff, 'put', `/leads/${id}/assignment`, { assigned_to: clients.other.id, version: 1 }).expect(403);
    await write(clients.staff, 'post', '/leads', { student_name: 'No assignment bypass', assigned_to: clients.other.id }).expect(403);
    await write(clients.staff, 'put', `/leads/${id}`, { ...leadInput.parse({ student_name: 'No bypass' }), assigned_to: clients.other.id, version: 1 }).expect(400);
  });
  test('Management is read-only and receives aggregates without lead contacts', async () => {
    const id = await newLead(clients.staff);
    const result = await clients.manager.agent.get('/api/dashboard').expect(200);
    assert.equal(typeof result.body.snapshot.total, 'number');
    assert.equal(JSON.stringify(result.body).includes('student_mobile'), false);
    await clients.manager.agent.get('/api/leads').expect(403);
    await clients.manager.agent.get(`/api/leads/${id}`).expect(403);
    await write(clients.manager, 'post', '/leads', { student_name: 'Blocked' }).expect(403);
    await clients.manager.agent.get('/api/leads/export').expect(403);
  });
  test('Admin can only manage Staff and OnField accounts', async () => {
    await write(clients.admin, 'post', '/users', { username: 'BadAdmin', email: 'bad@test.invalid', role: 'Admin', password: pass, is_active: true }).expect(403);
    await write(clients.admin, 'put', `/users/${clients.super.id}`, { username: 'super', email: 'super@test.invalid', role: 'Staff', is_active: true }).expect(403);
    const result = await write(clients.admin, 'post', '/users', { username: 'CreatedStaff', email: 'created@test.invalid', role: 'Staff', password: pass, is_active: true }).expect(201);
    await write(clients.super, 'delete', `/users/${result.body.user_id}`).expect(200);
    await clients.staff.agent.get('/api/users').expect(403);
    await clients.field.agent.get('/api/assignees').expect(403);
  });
});

describe('lead journey and concurrent operations', () => {
  test('call attempts are transactional and stale updates cannot overwrite data', async () => {
    const id = await newLead(clients.staff);
    const attempt = { call_outcome: 'Unanswered', followup_notes: 'Rang with no answer', lead_status: 'CALLBACK', next_followup_date: '2026-11-10', next_followup_time: '10:30', version: 1 };
    const results = await Promise.all([write(clients.staff, 'post', `/leads/${id}/calls`, attempt), write(clients.staff, 'post', `/leads/${id}/calls`, attempt)]);
    assert.deepEqual(results.map(r => r.status).sort(), [201, 409]);
    const lead = (await clients.staff.agent.get(`/api/leads/${id}`).expect(200)).body;
    assert.equal(lead.callno, 1);
    assert.equal(lead.version, 2);
    assert.equal(lead.next_followup_time, '10:30');
    assert.equal(lead.timeline.filter((e: { event_type: string }) => e.event_type === 'Call logged').length, 1);
    await write(clients.staff, 'put', `/leads/${id}`, { ...leadInput.parse({ student_name: 'Stale Update' }), version: 1 }).expect(409);
  });
  test('queue uses exact campus-local schedule, excludes unscheduled/lost/admitted, and sorts chronologically', async () => {
    const dueEarly = await newLead(clients.other, { next_followup_date: '2000-01-01', next_followup_time: '08:00' });
    const dueLater = await newLead(clients.other, { next_followup_date: '2000-01-01', next_followup_time: '09:00' });
    const future = await newLead(clients.other, { next_followup_date: '2099-01-01', next_followup_time: '08:00' });
    const unscheduled = await newLead(clients.other);
    const lost = await newLead(clients.other, { lead_status: 'LOST', next_followup_date: '2000-01-01', next_followup_time: '08:00' });
    const admitted = await newLead(clients.other, { is_admission_confirmed: true, next_followup_date: '2000-01-01', next_followup_time: '08:00' });
    const due = (await clients.other.agent.get('/api/leads?queue=due').expect(200)).body.items.map((l: { lead_id: string }) => l.lead_id);
    assert.deepEqual(due, [dueEarly, dueLater]);
    for (const id of [future, unscheduled, lost, admitted]) assert.equal(due.includes(id), false);
    const upcoming = (await clients.other.agent.get('/api/leads?queue=upcoming')).body.items;
    assert.equal(upcoming[0].lead_id, future);
  });
  test('reassignment removes old access and prevents deactivation with assigned work', async () => {
    const id = await newLead(clients.staff);
    await write(clients.admin, 'put', `/users/${clients.staff.id}`, { username: 'staff', email: 'staff@test.invalid', role: 'Staff', is_active: false }).expect(409);
    await write(clients.admin, 'put', `/leads/${id}/assignment`, { assigned_to: clients.other.id, version: 1 }).expect(200);
    await clients.staff.agent.get(`/api/leads/${id}`).expect(404);
    await clients.other.agent.get(`/api/leads/${id}`).expect(200);
  });
  test('confirmation creates a timeline event and updates dashboard totals', async () => {
    const before = (await clients.staff.agent.get('/api/dashboard')).body;
    const id = await newLead(clients.staff);
    await write(clients.staff, 'put', `/leads/${id}`, { ...leadInput.parse({ student_name: 'Admitted Student', is_interested: true, is_parent_convinced: true, is_admission_confirmed: true }), version: 1 }).expect(200);
    const after = (await clients.staff.agent.get('/api/dashboard')).body;
    assert.equal(after.snapshot.admissions, before.snapshot.admissions + 1);
    assert.equal(after.employees[0].confirmations, before.employees[0].confirmations + 1);
    const lead = (await clients.staff.agent.get(`/api/leads/${id}`)).body;
    assert(lead.timeline.some((e: { event_type: string }) => e.event_type === 'Admission confirmed'));
  });
});

describe('field accountability and technical corrections', () => {
  test('field agents receive only assigned visits and cannot submit another agent’s report', async () => {
    const id = await newLead(clients.staff, { address: '12 Test Road', parent_mobile: '9876543210', quoted_fee: 10000 });
    await write(clients.staff, 'post', `/leads/${id}/visits`, { field_employee_id: clients.field.id, request_notes: 'Discuss course and fees with parent' }).expect(201);
    await write(clients.staff, 'post', `/leads/${id}/visits`, { field_employee_id: clients.field.id, request_notes: 'Duplicate request' }).expect(409);
    const list = (await clients.field.agent.get('/api/visits')).body.items;
    const visit = list.find((v: { lead_id: string }) => v.lead_id === id);
    assert(visit);
    assert.equal((await clients.otherfield.agent.get('/api/visits')).body.total, 0);
    const fieldLead = (await clients.field.agent.get(`/api/leads/${id}`)).body;
    assert.equal(fieldLead.quoted_fee, undefined);
    const report = { entry_date: '2020-01-01', address_visited: '12 Test Road', area: 'Test area', contact_verified: 'Verified', visit_report: 'Parent interested; requested a campus visit.', latitude: 17.385, longitude: 78.4867 };
    await write(clients.otherfield, 'put', `/visits/${visit.visit_id}/complete`, report).expect(404);
    await write(clients.field, 'put', `/visits/${visit.visit_id}/complete`, { ...report, longitude: null }).expect(400);
    await write(clients.field, 'put', `/visits/${visit.visit_id}/complete`, { ...report, entry_date: '2099-01-01' }).expect(400);
    await write(clients.field, 'put', `/visits/${visit.visit_id}/complete`, report).expect(200);
    await write(clients.field, 'put', `/visits/${visit.visit_id}/complete`, report).expect(409);
    await write(clients.super, 'put', `/visits/${visit.visit_id}`, { ...report, visit_report: 'Corrected field report after supervisor check.', correction_reason: 'Supervisor checked the report' }).expect(200);
    const lead = (await clients.staff.agent.get(`/api/leads/${id}`)).body;
    assert.equal(lead.visits[0].status, 'COMPLETED');
    assert(lead.timeline.some((e: { event_type: string }) => e.event_type === 'Field visit completed'));
    await write(clients.super, 'delete', `/visits/${visit.visit_id}`, { correction_reason: 'Duplicate report removed' }).expect(200);
  });
  test('only SuperAdmin can correct or delete call records and delete leads', async () => {
    const id = await newLead(clients.staff);
    await write(clients.staff, 'post', `/leads/${id}/calls`, { call_outcome: 'Answered', followup_notes: 'Discussed admissions', lead_status: 'WARM', next_followup_date: null, next_followup_time: null, version: 1 }).expect(201);
    const lead = (await clients.staff.agent.get(`/api/leads/${id}`)).body;
    const call = lead.calls[0].log_id;
    const correction = { call_outcome: 'Unanswered', followup_notes: 'Corrected disposition', correction_reason: 'Entered on the wrong record' };
    await write(clients.admin, 'put', `/calls/${call}`, correction).expect(403);
    await write(clients.super, 'put', `/calls/${call}`, correction).expect(200);
    await write(clients.super, 'delete', `/calls/${call}`, { correction_reason: 'Duplicate record confirmed' }).expect(200);
    assert.equal((await clients.staff.agent.get(`/api/leads/${id}`)).body.callno, 0);
    await write(clients.admin, 'delete', `/leads/${id}`, { version: 2 }).expect(403);
    await write(clients.super, 'delete', `/leads/${id}`, { version: 2 }).expect(200);
    await clients.staff.agent.get(`/api/leads/${id}`).expect(404);
  });
});

describe('data portability and configuration', () => {
  test('CSV import is validated before writing and rolls back invalid assignees', async () => {
    const count = async () => Number((await pool.query('SELECT count(*) FROM leads')).rows[0].count);
    const initial = await count();
    await clients.admin.agent.post('/api/leads/import').set('X-CSRF-Token', clients.admin.csrf).set('Content-Type', 'text/csv')
      .send('student_name,assigned_to\nValid Student,\nInvalid Student,not-a-uuid\n').expect(400);
    assert.equal(await count(), initial);
    await clients.admin.agent.post('/api/leads/import').set('X-CSRF-Token', clients.admin.csrf).set('Content-Type', 'text/csv')
      .send(`student_name,assigned_to\nValid Student,\nInvalid Student,${randomUUID()}\n`).expect(400);
    assert.equal(await count(), initial);
    const valid = await clients.admin.agent.post('/api/leads/import').set('X-CSRF-Token', clients.admin.csrf).set('Content-Type', 'text/csv')
      .send(`student_name,parent_name,assigned_to,whatsapp_opt_in\n"Imported, Student",=SUM(1),${clients.staff.id},true\n`).expect(201);
    assert.equal(valid.body.imported, 1);
    const csv = await clients.admin.agent.get('/api/leads/export').expect(200);
    assert(csv.text.includes(`"'=SUM(1)"`));
    await clients.staff.agent.get('/api/leads/export').expect(403);
  });
  test('dashboard dates and global timezone are validated', async () => {
    await clients.manager.agent.get('/api/dashboard?from=2026-02-30').expect(400);
    await clients.manager.agent.get('/api/dashboard?from=2026-10-10&to=2026-10-01').expect(400);
    await write(clients.admin, 'put', '/settings', { college_name: 'Blocked', timezone: 'UTC' }).expect(403);
    await write(clients.super, 'put', '/settings', { college_name: 'Shastra Test College', timezone: 'Invalid/Zone' }).expect(400);
    await write(clients.super, 'put', '/settings', { college_name: 'Shastra Test College', timezone: 'Asia/Kolkata' }).expect(200);
    const audit = await clients.super.agent.get('/api/audit').expect(200);
    assert(audit.body.some((a: { action: string }) => a.action === 'Updated global settings'));
  });
  test('logout invalidates the session and session cookie is HttpOnly', async () => {
    const separate = await login('staff@test.invalid', clients.staff.id);
    await write(separate, 'post', '/auth/logout').expect(200);
    await separate.agent.get('/api/leads').expect(401);
    const response = await request(app).get('/api/auth/me').expect(200);
    assert(String(response.headers['set-cookie']).includes('HttpOnly'));
    assert(String(response.headers['set-cookie']).includes('SameSite=Lax'));
  });
});
